import streamlit as st
import os
import sys
import glob
import pandas as pd
from pathlib import Path
from datetime import datetime
import threading
import time
import queue
import traceback

# 스레드 안전성을 위한 추가 import
try:
    from streamlit.runtime.scriptrunner import add_script_run_ctx, get_script_run_ctx
except ImportError:
    # 이전 버전 호환성
    add_script_run_ctx = lambda t, ctx=None: None
    get_script_run_ctx = lambda: None

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

# 전역 RAG 인스턴스 (전역 변수로 한 번만 초기화)
if 'GLOBAL_RAG_INSTANCES' not in globals():
    _GLOBAL_RAG_INSTANCES = None

def initialize_rag_system():
    """RAG 시스템 초기화 - 전역 변수 기반 (진짜 싱글톤)"""
    global _GLOBAL_RAG_INSTANCES
    
    if _GLOBAL_RAG_INSTANCES is not None:
        print("[GLOBAL] 기존 RAG 인스턴스 재사용")
        return _GLOBAL_RAG_INSTANCES
    
    try:
        print("[GLOBAL] 새 RAG 인스턴스 생성 - 최초 1회만")
        from rag.hybrid_retriever import HybridRetriever
        from rag.llm_bridge import HybridLLM
        from config import get_config
        
        # RAG 시스템 초기화
        config = get_config()
        retriever = HybridRetriever(config)
        llm = HybridLLM(config)
        
        _GLOBAL_RAG_INSTANCES = (retriever, llm, config)
        print("[GLOBAL] RAG 인스턴스 생성 완료 - 전역 저장")
        return _GLOBAL_RAG_INSTANCES
    except Exception as e:
        st.error(f"RAG 시스템 초기화 실패: {e}")
        return None, None, None

# RAG 시스템 초기화
print("[DEBUG] RAG 초기화 호출")
retriever, llm, config = initialize_rag_system()
print("[DEBUG] RAG 초기화 완료")

if retriever and llm and config:
    def retrieve(question, top_k=5):
        """검색 함수"""
        search_results = retriever.search(question, question_type="short")
        return [{'text': result.content, 'score': result.score} for result in search_results[:top_k]]
    
    def generate_answer_short(question, contexts):
        """질의응답용 단답형 답변 생성 (간단한 LLM 호출)"""
        context_text = "\n".join([ctx['text'] for ctx in contexts])
        
        # 질의응답용 프롬프트 - 상세하고 완전한 답변 요청
        enhanced_question = f"""참고자료를 바탕으로 다음 질문에 대해 상세하고 완전한 답변을 제공해주세요.

질문: {question}

답변 요구사항:
1. 참고자료의 내용을 충분히 활용하여 상세히 설명
2. 관련 조문, 기준, 절차가 있다면 모두 포함
3. 완전한 문장으로 작성
4. 답변을 중간에 끊지 말고 끝까지 완성
5. 최소 50자 이상의 상세한 설명

답변:"""
        
        return call_simple_llm(enhanced_question, context_text)
    
    def generate_answer_short_for_evaluation(question, contexts):
        """평가용 단답형 답변 생성 (기존 llm_bridge 사용)"""
        context_text = "\n".join([ctx['text'] for ctx in contexts])
        return llm.call_short(question, context_text)
    
    def generate_answer_mcq(question, choices, contexts):
        """선다형 답변 생성 (평가용)"""
        context_text = "\n".join([ctx['text'] for ctx in contexts])
        choices_dict = {chr(65+i): choice for i, choice in enumerate(choices)}
        return llm.call_mcq(question, choices_dict, context_text)
    
    def call_simple_llm(user_prompt, context=""):
        """질의응답용 간단한 LLM 호출"""
        full_prompt = f"""Context:
{context}

{user_prompt}"""
        
        try:
            # OpenAI 우선 시도
            if config.openai_api_key:
                import openai
                client = openai.OpenAI(api_key=config.openai_api_key, timeout=config.llm_timeout)
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": full_prompt}],
                    temperature=0.0,
                    max_tokens=config.max_tokens
                )
                return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"OpenAI 호출 실패: {e}")
        
        try:
            # Upstage 대안
            if config.upstage_api_key:
                import openai
                client = openai.OpenAI(
                    api_key=config.upstage_api_key,
                    base_url="https://api.upstage.ai/v1",
                    timeout=config.llm_timeout
                )
                response = client.chat.completions.create(
                    model="solar-mini",
                    messages=[{"role": "user", "content": full_prompt}],
                    temperature=0.0,
                    max_tokens=config.max_tokens
                )
                return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"Upstage 호출 실패: {e}")
        
        return "답변 생성에 실패했습니다."
    
    RAG_AVAILABLE = True
else:
    RAG_AVAILABLE = False

def extract_concise_answer(raw_answer):
    """답변을 7단어 이내로 추출 (평가용)"""
    if not raw_answer or raw_answer.strip() == "":
        return "정보 부족"
    
    text = raw_answer.strip()
    
    # 숫자 답변 추출 (기간, 금액 등)
    import re
    
    # 조문 번호 추출
    article_match = re.search(r'제\s*(\d+)\s*조(?:의\s*(\d+))?', text)
    if article_match:
        if article_match.group(2):
            return f"제{article_match.group(1)}조의{article_match.group(2)}"
        return f"제{article_match.group(1)}조"
    
    # 기간 추출 (일, 개월, 년)
    period_match = re.search(r'(\d+)\s*(일|개월|년|주|시간)', text)
    if period_match:
        return f"{period_match.group(1)}{period_match.group(2)}"
    
    # 금액 추출
    money_match = re.search(r'(\d+(?:,\d+)*)\s*(억|만)?\s*원', text)
    if money_match:
        amount = money_match.group(1).replace(',', '')
        unit = money_match.group(2) or ""
        return f"{amount}{unit}원"
    
    # 백분율 추출
    percent_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:%|퍼센트|프로)', text)
    if percent_match:
        return f"{percent_match.group(1)}%"
    
    # 기관명 추출
    org_match = re.search(r'([가-힣]+(?:위원회|청|부|처|원|공단|공사))', text)
    if org_match:
        return org_match.group(1)
    
    # 핵심 키워드 추출 (7단어 이내)
    words = text.replace(',', ' ').replace('.', ' ').split()
    korean_words = [w for w in words if len(w) > 1 and re.search(r'[가-힣]', w)]
    
    if korean_words:
        # 의미있는 단어들을 앞에서부터 최대 7개까지
        result_words = []
        for word in korean_words:
            if len(' '.join(result_words + [word])) <= 30:  # 약 7단어 정도 길이
                result_words.append(word)
            if len(result_words) >= 7:
                break
        
        if result_words:
            return ' '.join(result_words)
    
    # 최후의 수단: 첫 문장의 핵심 부분만
    sentences = text.split('.')
    if sentences and len(sentences[0]) > 10:
        first_sentence = sentences[0].strip()
        if len(first_sentence) <= 30:
            return first_sentence
        else:
            return first_sentence[:25] + "..."
    
    return text[:20] + "..." if len(text) > 20 else text

def format_answer_for_chat(question, raw_answer):
    """질의응답용 답변을 완전한 문장으로 포맷팅"""
    if not raw_answer or raw_answer.strip() == "":
        return "죄송합니다. 해당 질문에 대한 답변을 찾을 수 없습니다."
    
    # 원본 답변을 최대한 보존하고, 필요시에만 최소 보완
    answer = raw_answer.strip()
    
    # 답변이 이미 완전한 문장이면 그대로 반환
    if answer.endswith(('.', '다', '요', '음', '것', '니다', '습니다', '입니다')):
        return answer
    
    # 문장이 끊어진 경우 자연스럽게 완성
    if answer.endswith('으로') or answer.endswith('에서') or answer.endswith('는'):
        return f"{answer} 정해져 있습니다."
    
    # 답변이 목록이나 조건을 나열하다 끊어진 경우
    if '다음' in answer and ('각 호' in answer or '요건' in answer):
        return f"{answer} 모든 조건을 충족해야 합니다."
    
    # 기타 경우: 단순히 마침표만 추가
    return f"{answer}."

def add_to_chat_history(question, answer):
    """채팅 기록에 질문과 답변 추가"""
    st.session_state.chat_history.append({
        "type": "user",
        "content": question,
        "timestamp": datetime.now().strftime("%H:%M:%S")
    })
    st.session_state.chat_history.append({
        "type": "assistant", 
        "content": answer,
        "timestamp": datetime.now().strftime("%H:%M:%S")
    })

def display_chat_history():
    """채팅 기록 표시"""
    if st.session_state.chat_history:
        st.subheader("대화 기록")
        
        # 채팅 기록을 컨테이너에 표시 (간격 최소화)
        chat_container = st.container()
        with chat_container:
            for i, chat in enumerate(st.session_state.chat_history):
                if chat["type"] == "user":
                    st.markdown(f"**사용자 {chat['timestamp']}:** {chat['content']}")
                else:
                    st.markdown(f"**Assistant {chat['timestamp']}:** {chat['content']}")
                
                # 마지막 항목이 아닐 때만 구분선 (간격 줄이기)
                if i < len(st.session_state.chat_history) - 1:
                    st.markdown("<hr style='margin: 8px 0; border: 1px solid #e0e0e0;'>", unsafe_allow_html=True)

# 페이지 설정
st.set_page_config(
    page_title="통합 RAG 시스템", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if 'evaluation_running' not in st.session_state:
    st.session_state.evaluation_running = False
if 'progress_logs' not in st.session_state:
    st.session_state.progress_logs = []
if 'success_logs' not in st.session_state:
    st.session_state.success_logs = []
if 'failure_logs' not in st.session_state:
    st.session_state.failure_logs = []
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'log_queue' not in st.session_state:
    st.session_state.log_queue = queue.Queue(maxsize=500)
if 'global_log_callback' not in st.session_state:
    st.session_state.global_log_callback = None
if 'session_id' not in st.session_state:
    import uuid
    st.session_state.session_id = str(uuid.uuid4())[:8]

def safe_add_log(log_type, message):
    """스레드 안전한 로그 추가 - 디버깅 강화"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    
    print(f"[LOG-DEBUG] safe_add_log 호출: {log_type} - {message[:30]}...")
    
    try:
        if log_type == "progress":
            if hasattr(st.session_state, 'progress_logs'):
                st.session_state.progress_logs.append(log_entry)
                if len(st.session_state.progress_logs) > 100:
                    st.session_state.progress_logs.pop(0)
                print(f"[LOG-DEBUG] progress 로그 추가됨 - 총 {len(st.session_state.progress_logs)}개")
                    
        elif log_type == "success":
            if hasattr(st.session_state, 'success_logs'):
                st.session_state.success_logs.append(log_entry)
                print(f"[LOG-DEBUG] success 로그 추가됨 - 총 {len(st.session_state.success_logs)}개")
                
        elif log_type == "failure":
            if hasattr(st.session_state, 'failure_logs'):
                st.session_state.failure_logs.append(log_entry)
                print(f"[LOG-DEBUG] failure 로그 추가됨 - 총 {len(st.session_state.failure_logs)}개")
    except AttributeError as e:
        print(f"[LOG-DEBUG] AttributeError: {e}")
        # session_state에 접근할 수 없는 경우 무시
        pass

def enhanced_global_log_callback(log_type, message, module=""):
    """개선된 전역 로그 콜백 - 스레드 안전성과 큐 기반"""
    if module:
        formatted_msg = f"[{module}] {message}"
    else:
        formatted_msg = message
    
    # 콘솔 출력 (항상)
    print(f"[{log_type.upper()}] {formatted_msg}")
    
    # 웹 로그 처리 (스레드 안전하게)
    try:
        # 평가 진행 중에는 모든 로그를 progress로
        if hasattr(st.session_state, 'evaluation_running') and st.session_state.evaluation_running:
            safe_add_log("progress", formatted_msg)
        else:
            # 평가 완료 후에만 성공/실패 분류
            if any(keyword in message.lower() for keyword in ["실패", "오류", "error", "에러", "return code"]):
                safe_add_log("failure", formatted_msg)
            elif any(keyword in message.lower() for keyword in ["완료", "성공", "success", "초기화 완료", "연결 완료"]):
                safe_add_log("success", formatted_msg)
            else:
                safe_add_log("progress", formatted_msg)
    except Exception as e:
        # 웹 로그 실패해도 콘솔 출력은 계속
        print(f"[LOG-ERROR] 웹 로그 실패: {e}")

def safe_log_callback(log_type, message, module=""):
    """스레드 안전한 로그 콜백"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    formatted_msg = f"[{timestamp}] {f'[{module}] ' if module else ''}{message}"
    
    try:
        # 큐를 통한 스레드 안전한 로그 전달
        st.session_state.log_queue.put((log_type, formatted_msg), timeout=1)
    except (queue.Full, AttributeError):
        # 큐가 가득 찼거나 접근할 수 없는 경우 콘솔에만 출력
        print(f"[THREAD-SAFE] {formatted_msg}")

def process_log_queue_enhanced():
    """개선된 로그 큐 처리 - 디버깅 강화"""
    processed_count = 0
    max_process = 50  # 한 번에 처리할 최대 로그 수
    
    print(f"[QUEUE-DEBUG] 큐 처리 시작 - 큐 크기: {st.session_state.log_queue.qsize()}")
    
    while not st.session_state.log_queue.empty() and processed_count < max_process:
        try:
            item = st.session_state.log_queue.get_nowait()
            processed_count += 1
            
            print(f"[QUEUE-DEBUG] 큐에서 가져옴: {item}")
            
            if len(item) == 2:
                log_type, message = item
                safe_add_log(log_type, message)
                print(f"[QUEUE-DEBUG] {log_type} 로그 추가: {message[:50]}...")
                
            elif len(item) == 3 and item[0] == "control":
                # 제어 메시지 처리
                command, value = item[1], item[2]
                if command == "evaluation_running":
                    st.session_state.evaluation_running = value
                    print(f"[QUEUE-DEBUG] 평가 상태 변경: {value}")
                    
        except queue.Empty:
            print("[QUEUE-DEBUG] 큐가 비어있음")
            break
        except Exception as e:
            print(f"[QUEUE-ERROR] 로그 큐 처리 오류: {e}")
            break
    
    print(f"[QUEUE-DEBUG] 처리 완료 - {processed_count}개 로그 처리됨")
    return processed_count

# 전역 콜백을 개선된 버전으로 설정
st.session_state.global_log_callback = enhanced_global_log_callback

def get_excel_files():
    """루트 디렉토리의 Excel 파일 목록 (결과 파일 제외)"""
    excel_patterns = ["*.xlsx", "*.xls"]
    excel_files = []
    
    for pattern in excel_patterns:
        files = glob.glob(str(project_root / pattern))
        for f in files:
            filename = Path(f).name
            # Skip evaluation result files
            if not filename.startswith("evaluation_"):
                excel_files.append(filename)
    
    return sorted(excel_files)

def run_evaluation_thread(excel_file, mcq_limit, short_limit, progress_callback):
    """평가 실행 스레드 - 전역 인스턴스 강제 사용"""
    def thread_safe_callback(message):
        """스레드 안전한 진행상황 콜백 - 자동 타입 분류"""
        try:
            # 메시지 내용 기반 자동 분류
            if any(keyword in message for keyword in ["완료", "성공", "Success", "성공:", "100.0%", "저장 완료"]):
                log_type = "success"
            elif any(keyword in message for keyword in ["실패", "오류", "Error", "에러", "0.0%", "없음"]):
                log_type = "failure"
            else:
                log_type = "progress"
            
            st.session_state.log_queue.put((log_type, message), timeout=0.5)
        except:
            print(f"[EVAL-THREAD] {message}")
    
    try:
        # 전역 인스턴스 강제 전달
        global _GLOBAL_RAG_INSTANCES
        if _GLOBAL_RAG_INSTANCES is None:
            thread_safe_callback("전역 RAG 인스턴스가 없음")
            return
            
        retriever, llm, config = _GLOBAL_RAG_INSTANCES
        thread_safe_callback("전역 RAG 인스턴스 사용")
        
        # 평가기에 기존 인스턴스 전달
        from rag.evaluator import UnifiedEvaluator
        evaluator = UnifiedEvaluator(retriever=retriever, llm=llm, config=config)
        
        file_path = project_root / excel_file
        results = evaluator.evaluate_file(
            str(file_path), 
            mcq_limit, 
            short_limit,
            progress_callback=thread_safe_callback
        )
        
        if not results:
            thread_safe_callback("평가 실행 실패")
            return
            
        thread_safe_callback("평가 완료!")
        
    except Exception as e:
        thread_safe_callback(f"평가 스레드 오류: {str(e)}")
        import traceback
        thread_safe_callback(f"상세 오류: {traceback.format_exc()[:200]}...")
    
    finally:
        # 평가 완료 상태를 큐를 통해 설정
        try:
            st.session_state.log_queue.put(("control", "evaluation_running", False), timeout=1)
        except:
            pass
        thread_safe_callback("평가 완료")

def start_evaluation_thread_safe(excel_file, mcq_limit, short_limit):
    """스레드 안전한 평가 시작"""
    # 평가 상태 초기화
    st.session_state.evaluation_running = True
    st.session_state.progress_logs = []
    st.session_state.success_logs = []
    st.session_state.failure_logs = []
    
    # 스레드 생성 및 시작
    def progress_callback(log_type, message):
        safe_log_callback(log_type, message)
    
    thread = threading.Thread(
        target=run_evaluation_thread,
        args=(excel_file, mcq_limit, short_limit, progress_callback),
        name="evaluation_thread",
        daemon=True
    )
    
    # Streamlit 컨텍스트 추가 (가능한 경우)
    try:
        ctx = get_script_run_ctx()
        if ctx:
            add_script_run_ctx(thread, ctx)
    except:
        pass  # 컨텍스트 추가 실패해도 계속 진행
    
    thread.start()
    return thread

def run_management_task_safe(task_name):
    """관리 작업을 위한 스레드 안전한 래퍼"""
    def task_wrapper():
        try:
            safe_log_callback("progress", f"{task_name} 시작...")
            
            # 작업 실행
            if task_name == "벡터 재생성":
                run_reindexing_safe()
            elif task_name == "BM25 재생성":
                rebuild_bm25_safe()
            elif task_name == "백업":
                run_backup_safe()
                
        except Exception as e:
            safe_log_callback("failure", f"{task_name} 오류: {e}")
    
    thread = threading.Thread(target=task_wrapper, daemon=True)
    
    # 컨텍스트 추가 시도
    try:
        ctx = get_script_run_ctx()
        if ctx:
            add_script_run_ctx(thread, ctx)
    except:
        pass
    
    thread.start()

def run_reindexing_safe():
    """스레드 안전한 벡터 재생성"""
    import subprocess
    try:
        result = subprocess.run([
            sys.executable, 
            str(project_root / "reindex_upstage_docx.py")
        ], capture_output=True, text=True, timeout=3600)
        
        if result.returncode == 0:
            safe_log_callback("success", "벡터 재생성 완료")
            if result.stdout:
                output_lines = result.stdout.strip().split('\n')
                for line in output_lines[-3:]:  # 마지막 3줄만
                    if line.strip():
                        safe_log_callback("success", f"출력: {line.strip()}")
        else:
            safe_log_callback("failure", f"벡터 재생성 실패: return code {result.returncode}")
            
    except subprocess.TimeoutExpired:
        safe_log_callback("failure", "벡터 재생성 타임아웃 (1시간 초과)")
    except Exception as e:
        safe_log_callback("failure", f"벡터 재생성 오류: {e}")

def rebuild_bm25_safe():
    """스레드 안전한 BM25 재생성"""
    import subprocess
    try:
        result = subprocess.run([
            sys.executable,
            str(project_root / "pipeline_bm25_from_docx.py")
        ], capture_output=True, text=True, timeout=1800)
        
        if result.returncode == 0:
            safe_log_callback("success", "BM25 인덱스 재생성 완료")
        else:
            safe_log_callback("failure", f"BM25 재생성 실패: return code {result.returncode}")
            
    except subprocess.TimeoutExpired:
        safe_log_callback("failure", "BM25 재생성 타임아웃 (30분 초과)")
    except Exception as e:
        safe_log_callback("failure", f"BM25 재생성 오류: {e}")

def run_backup_safe():
    """스레드 안전한 백업"""
    import subprocess
    try:
        result = subprocess.run([
            sys.executable,
            str(project_root / "rag_backup.py")
        ], capture_output=True, text=True, timeout=300)
        
        if result.returncode == 0:
            safe_log_callback("success", "프로젝트 백업 완료")
            if result.stdout:
                output_lines = result.stdout.strip().split('\n')
                for line in output_lines:
                    if "백업 완료:" in line:
                        safe_log_callback("success", line.strip())
                        break
        else:
            safe_log_callback("failure", f"백업 실패: return code {result.returncode}")
            
    except subprocess.TimeoutExpired:
        safe_log_callback("failure", "백업 타임아웃 (5분 초과)")
    except Exception as e:
        safe_log_callback("failure", f"백업 오류: {e}")

def handle_evaluation_start(selected_file, mcq_limit, short_limit):
    """개선된 평가 시작 처리"""
    if not selected_file:
        st.error("파일을 선택해주세요.")
        return
    
    # 평가 상태 초기화
    st.session_state.evaluation_running = True
    st.session_state.progress_logs = []
    st.session_state.success_logs = []  
    st.session_state.failure_logs = []
    
    # 스레드 안전한 평가 시작
    try:
        thread = start_evaluation_thread_safe(selected_file, mcq_limit, short_limit)
        enhanced_global_log_callback("progress", f"평가 시작: {selected_file}")
        st.success(f"평가 시작: {selected_file}")
        st.rerun()
    except Exception as e:
        enhanced_global_log_callback("failure", f"평가 시작 실패: {e}")
        st.session_state.evaluation_running = False
        st.error(f"평가 시작 실패: {e}")

def handle_management_button(task_name):
    """관리 도구 버튼 처리 개선"""
    try:
        run_management_task_safe(task_name)
        enhanced_global_log_callback("progress", f"{task_name} 스레드 시작")
        st.success(f"{task_name}이 시작되었습니다. 진행 상황은 로그를 확인하세요.")
    except Exception as e:
        enhanced_global_log_callback("failure", f"{task_name} 시작 실패: {e}")
        st.error(f"{task_name} 시작 실패: {e}")

# 사이드바 - 기능 선택
st.sidebar.title("금융법령 RAG 시스템")
st.sidebar.markdown("---")

# 디버깅 완료 후 제거
# print(f"[DEBUG] radio 생성 직전 - session_state: {list(st.session_state.keys())}")

tab_selection = st.sidebar.radio(
    "기능 선택",
    ["질의응답", "평가 시스템", "관리 도구"],
    index=0,
    key=f"navigation_radio_{st.session_state.session_id}"
)

# print(f"[DEBUG] radio 생성 완료 - 선택값: {tab_selection}")

# 메인 콘텐츠 
if tab_selection == "질의응답":
    st.title("금융 법령 질의응답")
    st.caption("AI 기반 법령 질의응답 시스템 (단답형)")
    
    if not RAG_AVAILABLE:
        st.error("RAG 시스템을 사용할 수 없습니다. 모듈을 확인해주세요.")
        st.stop()
    
    # 채팅 기록 표시 (위쪽에)
    display_chat_history()
    
    # 질문 입력 영역 (아래쪽 고정) - 단일 Form 구조
    st.markdown("---")
    st.subheader("새 질문")
    
    with st.form(key="question_form", clear_on_submit=True):
        col_input, col_question, col_clear = st.columns([5, 1, 1])
        
        with col_input:
            question = st.text_input(
                "질문", 
                placeholder="예: 은행법 제1조의 목적은 무엇인가요?",
                label_visibility="hidden"
            )
        
        with col_question:
            st.write("")  # 정렬용 공간
            ask_button = st.form_submit_button("질문", use_container_width=True)
            
        with col_clear:
            st.write("")  # 정렬용 공간
            clear_button = st.form_submit_button("초기화", use_container_width=True)
    
    # Form 외부에서 버튼 동작 처리
    if clear_button:
        st.session_state.chat_history = []
        # 즉시 새로고침 제거 - 페이지는 자동으로 업데이트됨
        # st.rerun()  # 제거
    
    if ask_button and question.strip():
        with st.spinner("검색 중..."):
            try:
                contexts = retrieve(question, top_k=5)
            except Exception as e:
                st.error(f"검색 오류: {e}")
                st.stop()
        
        if not contexts:
            answer = "죄송합니다. 관련 문서를 찾을 수 없습니다."
        else:
            # 답변 생성 (질의응답용 - 완전한 문장)
            with st.spinner("답변 생성 중..."):
                try:
                    raw_answer = generate_answer_short(question, contexts)
                    answer = format_answer_for_chat(question, raw_answer)
                except Exception as e:
                    answer = f"답변 생성 중 오류가 발생했습니다: {e}"
        
        # 채팅 기록에 추가
        add_to_chat_history(question, answer)
        
        # 검색 결과도 표시 (접을 수 있게)
        if contexts:
            with st.expander("검색 결과 보기"):
                for i, ctx in enumerate(contexts[:3], 1):
                    st.write(f"**[{i}]** Score: {ctx['score']:.3f}")
                    st.write(f"{ctx['text'][:200]}...")
        
        # 새로 고침 제거 - 자동으로 업데이트됨
        # st.rerun()  # 제거
    elif ask_button and not question.strip():
        st.warning("질문을 입력해주세요")

elif tab_selection == "평가 시스템":
    st.title("평가 시스템")
    st.caption("RAG 시스템 성능 평가 도구")
    
    if not RAG_AVAILABLE:
        st.error("RAG 시스템을 사용할 수 없습니다.")
        st.stop()
    
    # 평가 설정
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("평가 설정")
        
        # Excel 파일 선택
        excel_files = get_excel_files()
        if not excel_files:
            st.error("루트 디렉토리에 Excel 파일이 없습니다.")
            selected_file = None
        else:
            selected_file = st.selectbox(
                "평가할 Excel 파일",
                excel_files,
                help="루트 디렉토리의 Excel 파일 중 선택"
            )
        
        # 평가 옵션
        col_mcq, col_short = st.columns(2)
        with col_mcq:
            mcq_limit = st.number_input(
                "선다형 최대 문제 수",
                min_value=1,
                max_value=500,
                value=50,
                step=10
            )
        
        with col_short:
            short_limit = st.number_input(
                "단답형 최대 문제 수",
                min_value=1,
                max_value=500,
                value=50,
                step=10
            )
        
        # 평가 시작 버튼
        if st.button(
            "평가 시작", 
            type="primary", 
            disabled=st.session_state.evaluation_running or not selected_file,
            use_container_width=True
        ):
            handle_evaluation_start(selected_file, mcq_limit, short_limit)
    
    with col2:
        st.subheader("평가 상태")
        
        if st.session_state.evaluation_running:
            st.info("평가 진행 중...")
            progress_bar = st.progress(0)
            
            # 진행률 표시 (단순 애니메이션)
            if 'progress_value' not in st.session_state:
                st.session_state.progress_value = 0
            
            st.session_state.progress_value = (st.session_state.progress_value + 0.1) % 1.0
            progress_bar.progress(st.session_state.progress_value)
            
            if st.button("평가 중지", type="secondary"):
                st.session_state.evaluation_running = False
                enhanced_global_log_callback("progress", "사용자가 평가를 중지했습니다")
                # 중지 후 새로고침 제거
                # st.rerun()  # 제거
        else:
            st.success("평가 대기 중")
    
    # 로그 창들
    st.markdown("---")
    
    # 3개 컬럼으로 로그 창 배치
    log_col1, log_col2, log_col3 = st.columns(3)
    
    with log_col1:
        st.subheader("진행 상황")
        if st.session_state.progress_logs:
            log_text = "\n".join(st.session_state.progress_logs[-25:])  # 최근 25개만
            st.text_area("진행 로그", value=log_text, height=350, key="progress_logs_area", label_visibility="hidden")
        else:
            st.text_area("진행 로그", value="진행 로그가 없습니다.", height=350, key="progress_empty", label_visibility="hidden")
    
    with log_col2:
        st.subheader("성공 로그")
        if st.session_state.success_logs:
            log_text = "\n".join(st.session_state.success_logs[-25:])
            st.text_area("성공 로그", value=log_text, height=350, key="success_logs_area", label_visibility="hidden")
        else:
            st.text_area("성공 로그", value="성공 로그가 없습니다.", height=350, key="success_empty", label_visibility="hidden")
    
    with log_col3:
        st.subheader("실패 로그")
        if st.session_state.failure_logs:
            log_text = "\n".join(st.session_state.failure_logs[-25:])
            st.text_area("실패 로그", value=log_text, height=350, key="failure_logs_area", label_visibility="hidden")
        else:
            st.text_area("실패 로그", value="실패 로그가 없습니다.", height=350, key="failure_empty", label_visibility="hidden")
    
    # 자동 새로고침 (평가 진행 중일 때만) - 수정된 버전
    if st.session_state.evaluation_running:
        # 큐에서 로그 처리
        processed = process_log_queue_enhanced()
        
        # 새로고침 조건을 더 엄격하게 제한
        if processed > 0:
            # 로그가 처리되었을 때만 새로고침
            time.sleep(0.5)  # 1초 → 0.5초로 단축
            st.rerun()
        else:
            # 로그가 없으면 새로고침 주기를 늘림
            time.sleep(3)  # 2초 → 3초로 증가
            # 5번에 1번만 새로고침 (무한루프 방지)
            if not hasattr(st.session_state, 'rerun_counter'):
                st.session_state.rerun_counter = 0
            st.session_state.rerun_counter += 1
            if st.session_state.rerun_counter % 5 == 0:
                st.rerun()
    else:
        # 평가 완료 후에도 남은 로그 처리 (새로고침 없이)
        process_log_queue_enhanced()
        # 평가 완료 시 카운터 리셋
        if hasattr(st.session_state, 'rerun_counter'):
            del st.session_state.rerun_counter

elif tab_selection == "관리 도구":
    st.title("시스템 관리 도구")
    st.caption("데이터 재생성 및 시스템 관리")
    
    # 3개 컬럼으로 변경
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.subheader("벡터 데이터베이스")
        st.markdown("**Pinecone 벡터 인덱스 재생성**")
        st.markdown("- DOCX 문서 → 벡터 임베딩 → Pinecone 업로드")
        st.markdown("- 시간: 약 30분 ~ 2시간")
        
        if st.button("벡터 재생성 시작", type="primary", key="vector_btn"):
            handle_management_button("벡터 재생성")
    
    with col2:
        st.subheader("BM25 검색 인덱스")
        st.markdown("**BM25 검색 인덱스 재생성**")
        st.markdown("- DOCX 문서 → 텍스트 추출 → BM25 인덱스")
        st.markdown("- 시간: 약 10분 ~ 30분")
        
        if st.button("BM25 재생성 시작", type="secondary", key="bm25_btn"):
            handle_management_button("BM25 재생성")
    
    with col3:
        st.subheader("프로젝트 백업")
        st.markdown("**소스코드 백업**")
        st.markdown("- 모든 .py 파일 압축")
        st.markdown("- backup 폴더에 저장")
        st.markdown("- 시간: 약 10초 ~ 1분")
        
        if st.button("백업 실행", type="secondary", key="backup_btn"):
            handle_management_button("백업")
    
    # 관리 도구 로그
    st.markdown("---")
    st.subheader("관리 로그")
    
    # 통합 로그 표시
    all_logs = []
    all_logs.extend([(log, "진행") for log in st.session_state.progress_logs])
    all_logs.extend([(log, "성공") for log in st.session_state.success_logs])
    all_logs.extend([(log, "실패") for log in st.session_state.failure_logs])
    
    # 시간순 정렬 (로그 앞쪽의 timestamp 기준)
    all_logs.sort(key=lambda x: x[0][:9])  # [HH:MM:SS] 부분으로 정렬
    
    if all_logs:
        # 최근 50개만 표시
        recent_logs = all_logs[-50:]
        log_display = []
        for log_msg, log_type in recent_logs:
            prefix = {"성공": "✓", "실패": "✗", "진행": "-"}[log_type]
            log_display.append(f"{prefix} {log_msg}")
        
        log_text = "\n".join(log_display)
        st.text_area("관리 로그", value=log_text, height=400, key="management_logs", label_visibility="hidden")
    else:
        st.text_area("관리 로그", value="관리 로그가 없습니다.", height=400, key="management_empty", label_visibility="hidden")
    
    if st.button("로그 초기화", key=f"clear_logs_{st.session_state.session_id}"):
        st.session_state.progress_logs = []
        st.session_state.success_logs = []
        st.session_state.failure_logs = []
        st.success("로그가 초기화되었습니다.")
        # 로그 초기화 후 새로고침 제거
        # st.rerun()  # 제거

# 푸터
st.markdown("---")
st.markdown(
    f"<div style='text-align: center; color: #666; font-size: 0.8em;'>"
    f"금융법령 통합 RAG 시스템 v2.0 | 현재 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    f"</div>",
    unsafe_allow_html=True
)