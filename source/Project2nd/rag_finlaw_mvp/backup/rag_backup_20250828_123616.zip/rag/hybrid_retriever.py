"""
hybrid_retriever.py - 2차 개선 버전 (로그 시스템 완전 통합)
핵심 개선: BM25 실패율 감소, Vector 강화 모드 최적화, 더 적극적인 폴백 전략
"""
import os
import pickle
import re
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import streamlit as st

from rag.embedder_upstage import get_embedder
from rag.utils import SearchResult

def log_message(message):
    """로그 출력 - 웹 인터페이스와 콘솔"""
    print(f"[RETRIEVER] {message}")  # 콘솔 출력
    if hasattr(st.session_state, 'global_log_callback') and st.session_state.global_log_callback:
        # 웹 인터페이스 로그
        st.session_state.global_log_callback("progress", message, "RETRIEVER")

class HybridRetriever:
    """2차 개선된 하이브리드 검색기"""
    
    def __init__(self, config):
        log_message("2차 개선된 하이브리드 검색기 초기화 중...")
        self.config = config
        
        self.embedder = get_embedder()
        
        self.bm25_index = None
        self.corpus = None
        self._load_bm25()
        
        self.pinecone_index = None
        self._init_pinecone()
        
        # 검색 실패 통계 추적 (확장)
        self.search_stats = {
            'bm25_failures': 0,
            'vector_fallbacks': 0,
            'keyword_fallbacks': 0,
            'pattern_fallbacks': 0,
            'total_queries': 0
        }
        
        log_message(f"2차 개선 모드로 초기화 완료 (BM25: {self.bm25_index is not None}, Vector: {self.pinecone_index is not None})")

    def _load_bm25(self):
        """BM25 인덱스 로드"""
        if not os.path.exists(self.config.bm25_index_path):
            log_message("BM25 인덱스 파일이 존재하지 않음")
            return
        
        try:
            with open(self.config.bm25_index_path, 'rb') as f:
                data = pickle.load(f)
            
            if isinstance(data, dict) and "bm25" in data and "corpus" in data:
                self.bm25_index = data["bm25"]
                self.corpus = data["corpus"]
                log_message(f"BM25 로드 성공 ({len(self.corpus)}개 문서)")
            else:
                log_message("BM25 데이터 형식이 올바르지 않음")
        except Exception as e:
            log_message(f"BM25 로드 실패: {e}")

    def _init_pinecone(self):
        """Pinecone 초기화"""
        if not self.config.pinecone_api_key:
            log_message("Pinecone API 키가 설정되지 않음")
            return
        
        try:
            from pinecone import Pinecone
            pc = Pinecone(api_key=self.config.pinecone_api_key)
            self.pinecone_index = pc.Index(self.config.pinecone_index_name)
            log_message("Pinecone 연결 완료")
        except Exception as e:
            log_message(f"Pinecone 연결 실패: {e}")

    def _legal_tokenize_aggressive(self, text: str, debug: bool = False) -> List[str]:
        """더욱 적극적인 토크나이저 - BM25 실패율 감소를 위해"""
        tokens = []
        debug_info = []
        
        # 1. 조문 패턴 (가중치 유지)
        article_patterns = [
            r'제\s*\d+\s*조(?:제\s*\d+\s*항)?(?:제\s*\d+\s*호)?',
            r'제\s*\d+\s*조',
            r'제\d+조'
        ]
        
        article_found = 0
        for pattern in article_patterns:
            articles = re.findall(pattern, text)
            for article in articles:
                tokens.extend([article] * 3)
                article_found += 1
        
        if debug and article_found > 0:
            debug_info.append(f"조문:{article_found}개x3")
        
        # 2. 확장된 동의어 매핑 (더 적극적)
        expanded_synonyms = {
            # 기관명 확장
            "중소벤처기업부": ["중기부", "중소기업부", "중소벤처부", "벤처기업부"],
            "금융위원회": ["금위", "금융위", "금융감독위"],
            "공정거래위원회": ["공정위", "공거위", "공정거래위"],
            "방송통신위원회": ["방통위", "방송위", "통신위"],
            "금융감독원": ["금감원", "금융감독청"],
            "기획재정부": ["기재부", "재정부", "기획재정청"],
            "보건복지부": ["복지부", "보건부"],
            "고용노동부": ["노동부", "고용부"],
            "산업통상자원부": ["산자부", "산업부", "통상부"],
            
            # 법령 용어 확장
            "별지": ["별지서식", "서식", "양식"],
            "신청서": ["신청서류", "신청양식", "접수서류"],
            "등록": ["등기", "신고", "접수", "허가"],
            "승인": ["허가", "인가", "승인서"],
            "통지": ["고지", "알림", "공지"],
            "제출": ["첨부", "송부", "전달"],
            
            # 기간 표현 확장
            "이내": ["내", "까지", "이하"],
            "이상": ["넘는", "초과", "상회"],
            "미만": ["아래", "이하", "못미치는"],
            
            # 금액 단위 확장
            "억원": ["억", "100000000원"],
            "만원": ["만", "10000원"],
            "천원": ["천", "1000원"]
        }
        
        synonym_added = 0
        for standard, variants in expanded_synonyms.items():
            if standard in text:
                tokens.extend(variants)
                synonym_added += len(variants)
            else:
                for variant in variants:
                    if variant in text:
                        tokens.extend([standard] + [v for v in variants if v != variant])
                        synonym_added += len(variants)
                        break
        
        if debug and synonym_added > 0:
            debug_info.append(f"동의어:{synonym_added}개")
        
        # 3. 기존 토큰 추출
        korean_words = re.findall(r'[가-힣]{2,}', text)
        tokens.extend(korean_words)
        
        numbers = re.findall(r'\d+', text)
        tokens.extend(numbers)
        
        # 4. 더 다양한 법령 패턴
        enhanced_patterns = [
            r'\d+(?:년|개월|일)(?:\s*(?:이내|이상|미만|전|후|까지))?',
            r'\d+(?:억|만|천)?원(?:\s*(?:이상|이하|미만|초과))?',
            r'별지\s*(?:제\s*)?\d+\s*(?:호|번)(?:서식|양식)?',
            r'[가-힣]+(?:위원회|청|부|처|원)(?:장관?)?',
            r'제\s*\d+\s*(?:항|호|목)',
            r'(?:신청|허가|승인|등록|신고|접수|처리|발급|제출)(?:서|절차|방법|기간)?'
        ]
        
        pattern_added = 0
        for pattern in enhanced_patterns:
            matches = re.findall(pattern, text)
            tokens.extend(matches)
            pattern_added += len(matches)
        
        if debug and pattern_added > 0:
            debug_info.append(f"패턴:{pattern_added}개")
        
        # 5. 문맥 키워드 추가 (새로운 기능)
        context_keywords = self._extract_contextual_keywords(text)
        tokens.extend(context_keywords)
        
        if debug and context_keywords:
            debug_info.append(f"문맥:{len(context_keywords)}개")
        
        # 디버깅 출력
        if debug and debug_info:
            log_message(f"TOKENIZER {' '.join(debug_info)}")
        
        # 중복 제거하되 순서 보존
        seen = set()
        unique_tokens = []
        for token in tokens:
            if token not in seen:
                unique_tokens.append(token)
                seen.add(token)
        
        return unique_tokens

    def _extract_contextual_keywords(self, text: str) -> List[str]:
        """문맥적 키워드 추출 - 법령 특화"""
        contextual_tokens = []
        
        # 업무/절차 관련 문맥
        if any(word in text for word in ["신청", "접수", "처리"]):
            contextual_tokens.extend(["신청절차", "접수처리", "업무처리"])
        
        if any(word in text for word in ["허가", "승인", "인가"]):
            contextual_tokens.extend(["허가절차", "승인업무", "인가처리"])
        
        if any(word in text for word in ["등록", "신고", "등기"]):
            contextual_tokens.extend(["등록절차", "신고업무", "등기처리"])
        
        # 기간 관련 문맥
        if any(word in text for word in ["기간", "기한", "만료"]):
            contextual_tokens.extend(["처리기간", "신청기한", "유효기간"])
        
        # 서류 관련 문맥
        if any(word in text for word in ["서류", "서식", "문서"]):
            contextual_tokens.extend(["제출서류", "첨부서식", "필요서류"])
        
        return contextual_tokens

    def _bm25_search(self, query: str, top_k: int) -> List[SearchResult]:
        """BM25 검색 - 강화된 토크나이저 적용"""
        if not self.bm25_index:
            log_message("BM25 인덱스를 사용할 수 없음")
            return []
        
        # 강화된 토크나이저 사용
        query_tokens = self._legal_tokenize_aggressive(query, debug=False)
        
        if not query_tokens:
            query_tokens = query.split()
        
        if not query_tokens:
            log_message("검색 토큰이 없음")
            return []
        
        try:
            scores = self.bm25_index.get_scores(query_tokens)
        except Exception as e:
            log_message(f"BM25 점수 계산 오류: {e}")
            return []
        
        if len(scores) == 0:
            log_message("BM25 점수 결과 없음")
            return []
        
        max_score = max(scores)
        
        # 통계 업데이트
        if max_score == 0.0:
            self.search_stats['bm25_failures'] += 1
            log_message(f"BM25 매칭 실패 (누적: {self.search_stats['bm25_failures']}회)")
        else:
            log_message(f"BM25 매칭 성공 (최고:{max_score:.2f})")
        
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
        
        results = []
        for idx in top_indices:
            if idx < len(self.corpus) and scores[idx] > 0:
                results.append(SearchResult(
                    content=self.corpus[idx].get('text', ''),
                    score=float(scores[idx]),
                    metadata={
                        'search_method': 'bm25',
                        'index': idx,
                        'query_tokens_used': len(query_tokens),
                        **self.corpus[idx].get('metadata', {})
                    }
                ))
        
        return results

    def _vector_search_multi_fallback(self, query: str, top_k: int) -> List[SearchResult]:
        """다단계 Vector 검색 - 적극적인 폴백 전략"""
        if not self.pinecone_index:
            log_message("Vector 검색 불가 (Pinecone 없음)")
            return []
        
        try:
            # 1차: 원본 쿼리로 검색
            results = self._vector_search_single(query, top_k)
            max_score = max([r.score for r in results], default=0)
            log_message(f"Vector 1차 검색 완료 (최고점수: {max_score:.1f})")
            
            # 2차: 점수가 낮으면 키워드만으로 재검색
            if max_score < 45:  # 임계값 상향 조정 (40 → 45)
                keywords = re.findall(r'[가-힣]{3,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', query)
                if keywords:
                    keyword_query = " ".join(keywords[:4])  # 3개 → 4개로 확장
                    fallback_results = self._vector_search_single(keyword_query, top_k * 2)
                    
                    fallback_max = max([r.score for r in fallback_results], default=0)
                    if fallback_max > max_score:
                        results = fallback_results
                        self.search_stats['keyword_fallbacks'] += 1
                        log_message(f"키워드 폴백 적용 (누적: {self.search_stats['keyword_fallbacks']}회)")
            
            # 3차: 여전히 낮으면 법령 패턴만으로 재검색
            if max([r.score for r in results], default=0) < 35:  # 20 → 35로 상향
                legal_patterns = re.findall(r'제\d+조|\d+(?:년|개월|일)|\d+(?:억|만)?원|[가-힣]+(?:위원회|청|부|처|원)', query)
                if legal_patterns:
                    pattern_query = " ".join(legal_patterns)
                    pattern_results = self._vector_search_single(pattern_query, top_k * 3)
                    
                    pattern_max = max([r.score for r in pattern_results], default=0)
                    if pattern_max > max([r.score for r in results], default=0):
                        results = pattern_results
                        self.search_stats['pattern_fallbacks'] += 1
                        log_message(f"패턴 폴백 적용 (누적: {self.search_stats['pattern_fallbacks']}회)")
            
            # 4차: 여전히 결과가 없으면 유사어 확장 검색 (신규)
            if not results or max([r.score for r in results], default=0) < 25:
                expanded_query = self._expand_query_with_synonyms(query)
                if expanded_query != query:
                    expanded_results = self._vector_search_single(expanded_query, top_k * 2)
                    if expanded_results:
                        results = expanded_results
                        log_message("유사어 확장 폴백 적용")
            
            return results[:top_k]
            
        except Exception as e:
            log_message(f"Vector 검색 오류: {e}")
            return []

    def _expand_query_with_synonyms(self, query: str) -> str:
        """쿼리 유사어 확장"""
        # 주요 법령 용어의 유사어 매핑
        synonym_map = {
            "신청": "접수 제출 요청",
            "승인": "허가 인가 승낙",
            "등록": "등기 신고 접수",
            "기간": "기한 만료일 유효기간",
            "서류": "서식 문서 양식",
            "담당": "책임 관할 소관"
        }
        
        expanded_terms = []
        words = re.findall(r'[가-힣]{2,}', query)
        
        for word in words:
            expanded_terms.append(word)
            if word in synonym_map:
                expanded_terms.extend(synonym_map[word].split())
        
        # 원본 + 확장된 용어 (중복 제거)
        unique_terms = []
        seen = set()
        for term in expanded_terms:
            if term not in seen:
                unique_terms.append(term)
                seen.add(term)
        
        return " ".join(unique_terms[:8])  # 최대 8개 용어로 제한

    def _vector_search_single(self, query: str, top_k: int) -> List[SearchResult]:
        """단일 Vector 검색 실행"""
        query_embedding = self.embedder.embed_query(query)
        if not query_embedding:
            log_message("임베딩 생성 실패")
            return []
        
        try:
            response = self.pinecone_index.query(
                vector=query_embedding,
                top_k=top_k,
                include_metadata=True
            )
        except Exception as e:
            log_message(f"Pinecone 쿼리 오류: {e}")
            return []
        
        results = []
        for match in response['matches']:
            metadata = match['metadata'].copy()
            
            results.append(SearchResult(
                content=metadata.get('text', ''),
                score=float(match['score']) * 100,
                metadata={
                    'search_method': 'vector',
                    'vector_score': float(match['score']),
                    **metadata
                }
            ))
        
        return results

    def _get_bm25_threshold_adaptive(self, query: str, question_type: str) -> float:
        """적응형 BM25 임계값 - 더 관대하게"""
        if question_type == "short":
            # 쿼리 특성에 따른 동적 임계값
            if any(keyword in query for keyword in ["정의", "내용", "포함"]):
                return 0.3  # 정의/내용 질문은 더 관대
            elif any(keyword in query for keyword in ["조문", "제", "조"]):
                return 0.4  # 조문 질문은 약간 엄격
            else:
                return 0.2  # 일반 질문은 가장 관대
        return 0.0

    def search(self, query: str, question_type: str = "general", top_k: int = None) -> List[SearchResult]:
        """메인 검색 - 2차 개선 적용"""
        
        self.search_stats['total_queries'] += 1
        log_message(f"검색 시작 (쿼리: '{query[:50]}...' 유형: {question_type})")
        
        patterns = self._extract_question_patterns(query)
        
        if question_type == "MCQ":
            bm25_count = 3
            vector_count = 9
            bm25_weight = 0.2
            vector_weight = 0.8
            target_results = 10
        elif question_type == "short":
            bm25_count = 5
            vector_count = 7
            bm25_weight = 0.3
            vector_weight = 0.7
            target_results = 10
        else:
            bm25_count = 4
            vector_count = 8
            bm25_weight = 0.2
            vector_weight = 0.8
            target_results = 10
        
        # BM25 검색 (강화된 토크나이저)
        bm25_results = self._bm25_search(query, bm25_count * 2)
        bm25_max_score = max([r.score for r in bm25_results], default=0)
        
        # 적응형 임계값 적용
        bm25_threshold = self._get_bm25_threshold_adaptive(query, question_type)
        
        # BM25 실패 시 Vector 강화 모드 (더 적극적)
        if question_type == "short" and bm25_max_score < bm25_threshold:
            log_message(f"BM25 실패 (최고:{bm25_max_score:.1f}), Vector 강화 모드 진입")
            
            # Vector 검색 결과 수 대폭 증가
            vector_results = self._vector_search_multi_fallback(query, vector_count * 3)  # 2배 → 3배
            self.search_stats['vector_fallbacks'] += 1
            
            if patterns:
                vector_results = self._boost_pattern_matches(vector_results, patterns, question_type)
            
            final_results = self._diversify_by_source(vector_results, max_per_source=4)  # 3 → 4
            log_message(f"Vector 강화 완료: {len(final_results)}개 결과")
            return final_results
        else:
            # 정상 하이브리드 모드 (강화된 Vector 검색)
            vector_results = self._vector_search_multi_fallback(query, vector_count * 2)
            log_message(f"하이브리드 모드: BM25({bm25_count}) + Vector({vector_count})")
        
        # 패턴 부스팅 (기존 로직 유지)
        if patterns:
            bm25_results = self._boost_pattern_matches(bm25_results, patterns, question_type)
            vector_results = self._boost_pattern_matches(vector_results, patterns, question_type)
            log_message(f"패턴 부스팅 적용 ({len(patterns)}개 패턴)")
        
        # 결과 병합
        merged_results = self._merge_results_enhanced(
            bm25_results[:bm25_count], 
            vector_results[:vector_count],
            bm25_weight, 
            vector_weight, 
            target_results
        )
        
        # 다양성 확보 (더 관대하게)
        final_results = self._diversify_by_source(merged_results, max_per_source=4)
        
        log_message(f"검색 완료: {len(final_results)}개 결과")
        
        # 주기적 통계 출력 (더 자주)
        if self.search_stats['total_queries'] % 15 == 0:  # 20 → 15
            self._print_search_stats()
        
        return final_results

    def _extract_question_patterns(self, query: str) -> Dict[str, List[str]]:
        """질문 패턴 추출"""
        legal_patterns = {
            'articles': r'제\s*\d+\s*조(?:제\s*\d+\s*항)?(?:제\s*\d+\s*호)?',
            'periods': r'\d+\s*(?:년|개월|일)(?:\s*(?:이내|이상|미만))?',
            'amounts': r'\d+\s*(?:억|만)?\s*원(?:\s*(?:이상|이하|미만))?',
            'agencies': r'[가-힣]+(?:위원회|청|부|처|원)(?:장관?)?',
            'forms': r'별지\s*제\s*\d+\s*호(?:서식)?',
            'procedures': r'(?:신청|허가|승인|등록|신고|접수|처리|발급|제출)(?:서|절차|방법)?'
        }
        
        patterns = {}
        pattern_count = 0
        for pattern_name, pattern_regex in legal_patterns.items():
            matches = re.findall(pattern_regex, query)
            if matches:
                patterns[pattern_name] = matches
                pattern_count += len(matches)
        
        general_keywords = re.findall(r'[가-힣]{2,}', query)
        if general_keywords:
            patterns['keywords'] = general_keywords
        
        if pattern_count > 0:
            log_message(f"패턴 추출: {pattern_count}개")
        
        return patterns

    def _boost_pattern_matches(self, results: List[SearchResult], patterns: Dict[str, List[str]], 
                               question_type: str) -> List[SearchResult]:
        """패턴 부스팅"""
        if not patterns:
            return results
        
        boost_multiplier = 1.5 if question_type == "short" else 1.2
        boosted_count = 0
        
        for result in results:
            content = result.content
            total_boost = 0.0
            
            # 조문 패턴 부스팅 (가장 중요)
            if 'articles' in patterns:
                for article in patterns['articles']:
                    if article in content:
                        total_boost += 0.8
            
            # 기간 패턴 부스팅
            if 'periods' in patterns:
                for period in patterns['periods']:
                    if period in content:
                        total_boost += 0.6
            
            # 기관 패턴 부스팅
            if 'agencies' in patterns:
                for agency in patterns['agencies']:
                    if agency in content:
                        total_boost += 0.5
            
            if total_boost > 0:
                result.score = result.score * (1.0 + total_boost * boost_multiplier)
                result.metadata['pattern_boost'] = total_boost
                boosted_count += 1
            else:
                result.metadata['pattern_boost'] = 0.0
        
        if boosted_count > 0:
            log_message(f"패턴 부스팅 적용: {boosted_count}개 결과")
        
        return results

    def _diversify_by_source(self, results: List[SearchResult], max_per_source: int = 4) -> List[SearchResult]:
        """소스별 다양성 확보 - 더 관대하게"""
        source_counts = {}
        diversified = []
        
        for result in results:
            source = result.metadata.get('source_file', 'unknown')
            current_count = source_counts.get(source, 0)
            
            if current_count < max_per_source:
                diversified.append(result)
                source_counts[source] = current_count + 1
            
            if len(diversified) >= 12:  # 10 → 12로 증가
                break
        
        # 결과가 부족하면 소스 제한 완화
        if len(diversified) < 8:
            for result in results:
                if result not in diversified:
                    diversified.append(result)
                    if len(diversified) >= 12:
                        break
        
        log_message(f"다양성 확보: {len(diversified)}개 결과")
        return diversified

    def _merge_results_enhanced(self, bm25_results: List[SearchResult], vector_results: List[SearchResult], 
                            bm25_weight: float, vector_weight: float, target_count: int) -> List[SearchResult]:
        """결과 병합 - 향상된 방식"""
        all_results = []
        seen_content = set()
        
        log_message(f"결과 병합 시작: BM25 {len(bm25_results)}개, Vector {len(vector_results)}개")
        
        # Vector 결과를 먼저 추가 (우선순위)
        for result in vector_results:
            content_key = self._get_content_key(result.content)
            if content_key not in seen_content:
                result.metadata['final_score'] = result.score * vector_weight
                result.metadata['bm25_contribution'] = 0.0
                result.metadata['vector_contribution'] = result.score * vector_weight
                all_results.append(result)
                seen_content.add(content_key)
        
        # BM25 결과 추가
        for result in bm25_results:
            content_key = self._get_content_key(result.content)
            if content_key not in seen_content:
                result.metadata['final_score'] = result.score * bm25_weight
                result.metadata['bm25_contribution'] = result.score * bm25_weight
                result.metadata['vector_contribution'] = 0.0
                all_results.append(result)
                seen_content.add(content_key)
            else:
                # 중복 시 점수 합산
                for existing in all_results:
                    if self._get_content_key(existing.content) == content_key:
                        existing.metadata['final_score'] += result.score * bm25_weight
                        existing.metadata['bm25_contribution'] = result.score * bm25_weight
                        break
        
        # final_score로 정렬
        all_results.sort(key=lambda x: x.metadata.get('final_score', 0), reverse=True)
        
        final_results = all_results[:target_count]
        
        # 점수 업데이트
        for result in final_results:
            result.score = result.metadata.get('final_score', result.score)
        
        log_message(f"병합 완료: {len(final_results)}개 최종 결과")
        return final_results

    def _get_content_key(self, content: str) -> str:
        """컨텐츠 중복 판단용 키 생성"""
        return content[:150].strip()

    def _print_search_stats(self):
        """검색 통계 출력"""
        total = self.search_stats['total_queries']
        failures = self.search_stats['bm25_failures']
        vector_fallbacks = self.search_stats['vector_fallbacks']
        keyword_fallbacks = self.search_stats['keyword_fallbacks']
        pattern_fallbacks = self.search_stats['pattern_fallbacks']
        
        failure_rate = (failures / total * 100) if total > 0 else 0
        vector_rate = (vector_fallbacks / total * 100) if total > 0 else 0
        
        log_message(f"검색 통계 - 총:{total}회")
        log_message(f"  - BM25실패:{failures}회({failure_rate:.1f}%)")
        log_message(f"  - Vector강화:{vector_fallbacks}회({vector_rate:.1f}%)")
        log_message(f"  - 키워드폴백:{keyword_fallbacks}회, 패턴폴백:{pattern_fallbacks}회")