"""
evaluator.py - 평가 로깅 강화 및 상세 디버깅 버전 (로그 시스템 완전 통합)
핵심 개선: 부정형 질문 감지 로깅, 상세 원인 분석, MCQ 오답 패턴 추적, 웹 인터페이스 지원
"""
import time
import pandas as pd
import re
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Tuple, Callable, Optional
import streamlit as st

from rag.utils import (
    load_excel_data, save_evaluation_results,
    calculate_enhanced_exact_match, calculate_enhanced_f1_score,
    parse_mcq_answer, SearchResult
)

def log_message(message, module="EVALUATOR"):
    """로그 출력 - 웹 인터페이스와 콘솔"""
    print(f"[{module}] {message}")  # 콘솔 출력
    if hasattr(st.session_state, 'global_log_callback') and st.session_state.global_log_callback:
        # 웹 인터페이스 로그
        st.session_state.global_log_callback("progress", message, module)

class UnifiedEvaluator:
    """로깅 강화 및 상세 디버깅이 추가된 평가기 + 웹 인터페이스 지원"""
    
    def __init__(self, config=None, retriever=None, llm=None):
        log_message("평가기 초기화 중...")
        
        # 기존 인스턴스 재사용 또는 새로 생성
        if retriever and llm:
            # 전역 인스턴스 재사용 (중복 초기화 방지)
            self.retriever = retriever
            self.llm = llm
            self.config = config if config else getattr(retriever, 'config', None)
            log_message("기존 RAG 인스턴스 재사용")
        else:
            # 새 인스턴스 생성 (CLI 모드 등)
            if not config:
                from config import get_config
                config = get_config()
            
            self.config = config
            from rag.hybrid_retriever import HybridRetriever
            from rag.llm_bridge import HybridLLM
            
            self.retriever = HybridRetriever(config)
            self.llm = HybridLLM(config)
            log_message("새 RAG 인스턴스 생성")
        
        # 법령 용어 사전
        self.legal_synonyms = {
            "중기부": "중소벤처기업부",
            "금위": "금융위원회",
            "금감원": "금융감독원",
            "공정위": "공정거래위원회",
        }
        
        log_message("초기화 완료")

    def evaluate_mcq_batch(self, questions: List[Dict], max_questions: int = None, 
                          progress_callback: Optional[Callable] = None) -> Tuple[float, List[Dict]]:
        """MCQ 배치 평가 - 상세 로깅 및 오답 분석 강화"""
        if max_questions:
            questions = questions[:max_questions]
        
        if not questions:
            log_message("MCQ 질문이 없음")
            return 0.0, []
        
        log_message(f"MCQ 평가 시작: {len(questions)}개 문제")
        start_time = time.time()
        
        correct = 0
        results = []
        
        # 오답 패턴 추적용
        error_patterns = {
            'search_failure': 0,    # BM25=0, 낮은 검색 점수
            'choice_mapping': 0,    # 검색 성공, LLM 매핑 실패
            'context_quality': 0,   # 컨텍스트 품질 문제
            'negative_detection': 0  # 부정형 질문 감지 실패
        }
        
        for i, q in enumerate(questions):
            if progress_callback:
                progress = (i / len(questions)) * 100
                progress_callback(f"MCQ 진행: {i+1}/{len(questions)} ({progress:.1f}%)")
            
            item_start = time.time()
            log_message(f"MCQ-{i+1} 처리 시작: '{q['question'][:50]}...'")
            
            # MCQ 검색: BM25(6) + Vector(4) = 8개
            search_results = self.retriever.search(q['question'], question_type="MCQ")
            
            # 검색 점수 분석
            bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
            vector_scores = [r.metadata.get('vector_contribution', 0) for r in search_results]
            bm25_max = max(bm25_scores) if bm25_scores else 0
            vec_max = max(vector_scores) if vector_scores else 0
            
            log_message(f"MCQ-{i+1} 검색 완료: {len(search_results)}개 (BM25={bm25_max:.2f}, Vec={vec_max:.2f})")
            
            # 부정형 질문 감지 (로깅용)
            is_negative_question = self._detect_negative_question(q['question'])
            
            # 청크 품질 필터링
            filtered_results = self._filter_low_quality_chunks(search_results)
            
            # 컨텍스트 선택
            context = self._select_mcq_context_simple(q['question'], filtered_results)
            
            # LLM 처리
            choices_dict = {chr(65+i): choice for i, choice in enumerate(q['choices'])}
            llm_response = self.llm.call_mcq(q['question'], choices_dict, context)
            
            # 답변 파싱
            expected_format = q.get('answer_format', 'number')
            predicted = parse_mcq_answer(llm_response, expected_format)
            correct_answer = str(q.get('answer', '1')).strip()
            
            is_correct = (predicted == correct_answer)
            if is_correct:
                correct += 1
            else:
                # 오답 원인 분석
                error_type = self._analyze_mcq_error(
                    bm25_max, vec_max, context, q['question'], 
                    choices_dict, predicted, correct_answer, is_negative_question
                )
                error_patterns[error_type] += 1
            
            item_time = time.time() - item_start
            
            # 품질 지표 계산
            context_quality = self._assess_context_quality(context, q['question'])
            pattern_matches = self._count_pattern_matches(context, q['question'])
            
            # 강화된 로깅 - 부정형 감지 상태 포함
            filtered_count = len(filtered_results)
            original_count = len(search_results)
            filter_info = f"({filtered_count}/{original_count})" if filtered_count != original_count else ""
            
            question_type_str = "부정형" if is_negative_question else "일반형"
            
            if is_correct:
                # 정답일 때는 간단하게
                log_message(f"MCQ-{i+1} 성공: LLM='{predicted}'→'{correct_answer}' O ({item_time:.1f}s)")
            else:
                # 오답일 때는 전체 로그 유지
                log_message(f"MCQ-{i+1} 실패: 검색:{len(search_results)}개{filter_info}(BM25={bm25_max:.2f},Vec={vec_max:.2f}) "
                    f"컨텍스트:{len(context)}자(품질={context_quality:.2f}) 패턴:{pattern_matches}개 "
                    f"유형:{question_type_str} LLM='{predicted}'→'{correct_answer}' X ({item_time:.1f}s)")
            
            # 결과 저장
            results.append({
                'question': q['question'][:100],
                'predicted': predicted,
                'correct': correct_answer,
                'is_correct': is_correct,
                'choices': q['choices'],
                'context_preview': context[:150],
                'response_time': item_time,
                'llm_response': llm_response[:100],
                'bm25_max_score': bm25_max,
                'vector_max_score': vec_max,
                'context_length': len(context),
                'context_quality': context_quality,
                'pattern_matches': pattern_matches,
                'is_negative_question': is_negative_question,
                'question_type': question_type_str,
                'filtered_chunk_count': filtered_count,
                'original_chunk_count': original_count,
                'error_type': error_type if not is_correct else 'correct'
            })
        
        accuracy = correct / len(questions)
        total_time = time.time() - start_time
        
        # 오답 패턴 분석 출력
        total_errors = len(questions) - correct
        if total_errors > 0:
            error_summary = "MCQ 오답 패턴 분석: "
            error_details = []
            for pattern, count in error_patterns.items():
                if count > 0:
                    percentage = (count / total_errors) * 100
                    error_details.append(f"{pattern}: {count}개 ({percentage:.1f}%)")
            
            if error_details:
                error_summary += ", ".join(error_details)
                log_message(error_summary)
                
                if progress_callback:
                    progress_callback(error_summary)
        
        result_msg = f"MCQ 완료: {accuracy:.1%} ({correct}/{len(questions)}) - {total_time:.1f}초"
        log_message(result_msg)
        self._log(progress_callback, result_msg)
        
        return accuracy, results

    def evaluate_short_batch(self, questions: List[Dict], max_questions: int = None,
                            progress_callback: Optional[Callable] = None) -> Tuple[float, float, List[Dict]]:
        """단답형 배치 평가 - 기존 코드 완전 유지 + progress_callback 추가"""
        if max_questions:
            questions = questions[:max_questions]
        
        if not questions:
            log_message("단답형 질문이 없음")
            return 0.0, 0.0, []
        
        log_message(f"단답형 평가 시작: {len(questions)}개 문제")
        start_time = time.time()
        
        em_correct = 0
        f1_total = 0.0
        results = []
        
        for i, q in enumerate(questions):
            if progress_callback:
                progress = (i / len(questions)) * 100
                progress_callback(f"단답형 진행: {i+1}/{len(questions)} ({progress:.1f}%)")
            
            item_start = time.time()
            log_message(f"SHORT-{i+1} 처리 시작: '{q['question'][:50]}...'")
            
            # 단답형 검색: BM25(8) + Vector(2) = 10개
            search_results = self.retriever.search(q['question'], question_type="short")
            
            # 검색 점수 분석
            bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
            vector_scores = [r.metadata.get('vector_contribution', 0) for r in search_results]
            bm25_max = max(bm25_scores) if bm25_scores else 0
            vec_max = max(vector_scores) if vector_scores else 0
            
            log_message(f"SHORT-{i+1} 검색 완료: {len(search_results)}개 (BM25={bm25_max:.2f}, Vec={vec_max:.2f})")
            
            # 기존 단답형 파이프라인 사용
            predicted, scored_chunks = self._process_short_pipeline_fast(q['question'], search_results)
            
            # 정답 비교
            correct_answer = str(q.get('answer', '정보부족')).strip()
            
            # 법령 용어 정규화
            predicted_normalized = self._normalize_legal_answer(predicted)
            correct_normalized = self._normalize_legal_answer(correct_answer)
            
            # EM/F1 계산
            em_score = calculate_enhanced_exact_match(predicted_normalized, correct_normalized)
            f1_score = calculate_enhanced_f1_score(predicted_normalized, correct_normalized)
            
            if em_score:
                em_correct += 1
            f1_total += f1_score
            
            item_time = time.time() - item_start
            
            # 품질 지표 계산
            bm25_max_for_chunks = max([r.metadata.get('bm25_contribution', 0) for r in search_results], default=0)
            is_article_ref = "제" in q['question'] and "조에서" in q['question']
            
            if bm25_max_for_chunks > 100:
                expected_chunk_count = 5
            elif is_article_ref:
                expected_chunk_count = 4
            else:
                expected_chunk_count = 3
            
            if scored_chunks and len(scored_chunks) >= expected_chunk_count:
                context_parts = [chunk.content for chunk, score in scored_chunks[:expected_chunk_count]]
                full_context = "\n".join(context_parts)
            else:
                full_context = "컨텍스트 없음"
            
            context_quality = self._assess_context_quality(full_context, q['question'])
            pattern_matches = self._count_pattern_matches(full_context, q['question'])
            extraction_success = "추출성공" if len(predicted.strip()) > 3 and "정보 부족" not in predicted else "추출실패"
            
            if em_score:
                # 정답일 때는 간단하게
                log_message(f"SHORT-{i+1} 성공: LLM='{predicted}' EM=1.0 F1={f1_score:.2f} ({item_time:.1f}s)")
            else:
                # 오답일 때는 전체 로그 유지
                log_message(f"SHORT-{i+1} 실패: 검색:{len(search_results)}개(BM25={bm25_max:.2f},Vec={vec_max:.2f}) "
                    f"컨텍스트:{expected_chunk_count}개청크(품질={context_quality:.2f}) 패턴:{pattern_matches}개 "
                    f"추출:{extraction_success} LLM='{predicted}' EM={1.0 if em_score else 0.0:.1f} F1={f1_score:.2f} ({item_time:.1f}s)")
            
            # 결과 저장
            results.append({
                'question': q['question'][:100],
                'predicted': predicted,
                'predicted_normalized': predicted_normalized,
                'correct': correct_answer,
                'correct_normalized': correct_normalized,
                'em_score': 1.0 if em_score else 0.0,
                'f1_score': f1_score,
                'pipeline_method': "debug_enhanced",
                'response_time': item_time,
                'bm25_max_score': bm25_max,
                'vector_max_score': vec_max,
                'context_quality': context_quality,
                'pattern_matches': pattern_matches,
                'extraction_success': extraction_success,
                'chunk_count_used': expected_chunk_count
            })
        
        em_avg = em_correct / len(questions)
        f1_avg = f1_total / len(questions)
        total_time = time.time() - start_time
        
        result_msg = f"단답형 완료: EM={em_avg:.1%}, F1={f1_avg:.1%} - {total_time:.1f}초"
        log_message(result_msg)
        self._log(progress_callback, result_msg)
        
        return em_avg, f1_avg, results

    def evaluate_file(self, file_path: str, mcq_limit: int = None, short_limit: int = None,
                     progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """전체 파일 평가 - progress_callback 지원 추가"""
        log_message(f"파일 평가 시작: {Path(file_path).name}")
        
        eval_start_time = time.time()
        
        # 데이터 로드
        log_message("데이터 로드 중...")
        self._log(progress_callback, "데이터 로드 중...")
        mcq_questions, short_questions = load_excel_data(file_path, mcq_limit, short_limit)
        
        if not mcq_questions and not short_questions:
            error_msg = "평가할 질문이 없습니다."
            log_message(error_msg)
            self._log(progress_callback, error_msg)
            return {}
        
        load_msg = f"데이터 로드 완료: MCQ {len(mcq_questions)}개, 단답형 {len(short_questions)}개"
        log_message(load_msg)
        self._log(progress_callback, load_msg)
        
        # MCQ 평가
        mcq_accuracy = 0.0
        mcq_results = []
        if mcq_questions:
            log_message("MCQ 평가 실행 중...")
            self._log(progress_callback, "MCQ 평가 실행 중...")
            mcq_accuracy, mcq_results = self.evaluate_mcq_batch(
                mcq_questions, mcq_limit, progress_callback
            )
        
        # 단답형 평가
        short_em = short_f1 = 0.0
        short_results = []
        if short_questions:
            log_message("단답형 평가 실행 중...")
            self._log(progress_callback, "단답형 평가 실행 중...")
            short_em, short_f1, short_results = self.evaluate_short_batch(
                short_questions, short_limit, progress_callback
            )
        
        total_eval_time = time.time() - eval_start_time
        
        # 결과 정리
        evaluation_results = {
            'mcq_accuracy': mcq_accuracy,
            'short_em': short_em,
            'short_f1': short_f1,
            'mcq_total': len(mcq_results),
            'short_total': len(short_results),
            'total_questions': len(mcq_results) + len(short_results),
            'mcq_results': mcq_results,
            'short_results': short_results,
            'source_file': Path(file_path).name,
            'total_time': total_eval_time,
            'improvement_info': {
                'debug_logging_enhanced': True,
                'error_pattern_analysis': True,
                'negative_question_detection': True,
                'choice_relevance_calculation': True,
                'web_interface_support': True
            }
        }
        
        self._print_summary(evaluation_results)
        log_message("평가 완료")
        self._log(progress_callback, "평가 완료")
        return evaluation_results

    def _log(self, progress_callback: Optional[Callable], message: str):
        """로그 출력 헬퍼"""
        if progress_callback:
            progress_callback(message)

    def _detect_negative_question(self, question: str) -> bool:
        """부정형 질문 감지 (로깅용)"""
        negative_indicators = [
            "포함되지 않는", "해당하지 않는", "맞지 않는", "아닌 것",
            "제외되는", "틀린 것", "잘못된 것", "예외"
        ]
        
        for indicator in negative_indicators:
            if indicator in question:
                log_message(f"부정형 표현 감지: '{indicator}'")
                return True
        
        # 문맥적 패턴
        if re.search(r"다음.*?중.*?(?:아닌|않은|없는)", question):
            log_message("부정형 패턴 감지")
            return True
        
        return False

    def _analyze_mcq_error(self, bm25_max: float, vec_max: float, context: str, 
                          question: str, choices: Dict, predicted: str, 
                          correct: str, is_negative: bool) -> str:
        """MCQ 오답 원인 분석"""
        
        # 1. 검색 실패형 (BM25 < 5.0 이고 Vector도 낮음)
        if bm25_max < 5.0 and vec_max < 1.0:
            return 'search_failure'
        
        # 2. 부정형 질문 감지 실패 (부정형인데 일반형으로 처리된 경우)
        if is_negative and not self._check_negative_processing_in_context(context, choices):
            return 'negative_detection'
        
        # 3. 컨텍스트 품질 문제 (검색은 되지만 품질이 낮음)
        context_quality = self._assess_context_quality(context, question)
        if context_quality < 0.4:
            return 'context_quality'
        
        # 4. 선택지 매핑 오류 (검색과 컨텍스트는 양호)
        return 'choice_mapping'

    def _check_negative_processing_in_context(self, context: str, choices: Dict) -> bool:
        """부정형 질문 처리가 제대로 되었는지 확인"""
        # 간단한 휴리스틱: 모든 선택지가 컨텍스트에 어느 정도 언급되어 있는지 확인
        mentioned_count = 0
        for choice_text in choices.values():
            choice_keywords = set(re.findall(r'[가-힣]{3,}', choice_text))
            context_keywords = set(re.findall(r'[가-힣]{3,}', context))
            
            if len(choice_keywords & context_keywords) > 0:
                mentioned_count += 1
        
        # 4개 중 3개 이상이 언급되면 부정형 처리가 필요했던 상황
        return mentioned_count >= 3

    def _filter_low_quality_chunks(self, search_results: List[SearchResult]) -> List[SearchResult]:
        """저품질 청크 필터링"""
        if not search_results:
            return search_results
        
        filtered = []
        filtered_count = 0
        
        for result in search_results:
            bm25_score = result.metadata.get('bm25_contribution', 0)
            vector_score = result.metadata.get('vector_contribution', 0)
            
            # 필터링 조건: BM25 < 1.0 AND Vector < 0.3 인 청크 제외
            if bm25_score < 1.0 and vector_score < 0.3:
                filtered_count += 1
                continue  # 제외
            
            # 추가 조건: 내용이 너무 짧은 청크 제외
            if len(result.content.strip()) < 50:
                filtered_count += 1
                continue  # 제외
            
            filtered.append(result)
        
        # 필터링 결과가 너무 적으면 원본 일부 복원
        if len(filtered) < 2 and len(search_results) > 0:
            # 상위 2개는 무조건 포함
            for result in search_results[:2]:
                if result not in filtered:
                    filtered.append(result)
        
        if filtered_count > 0:
            log_message(f"저품질 청크 {filtered_count}개 필터링")
        
        return filtered

    def _select_mcq_context_simple(self, question: str, search_results: List[SearchResult]) -> str:
        """MCQ 컨텍스트 선택"""
        if not search_results:
            return "관련 정보를 찾을 수 없습니다."
        
        # BM25 점수 확인
        bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
        bm25_max_score = max(bm25_scores) if bm25_scores else 0
        
        # 동적 청크 개수
        if bm25_max_score > 50:
            chunk_count = 4
        else:
            chunk_count = 3
        
        # 검색기 점수를 그대로 활용
        scored_chunks = []
        for result in search_results:
            score = result.metadata.get('final_score', result.score)
            scored_chunks.append((result, score))
        
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        selected_chunks = scored_chunks[:chunk_count]
        
        context_parts = []
        for i, (chunk, score) in enumerate(selected_chunks, 1):
            context_parts.append(f"[참고자료 {i}]\n{chunk.content}")
        
        log_message(f"MCQ 컨텍스트 구성: {chunk_count}개 청크")
        return "\n\n".join(context_parts)

    def _process_short_pipeline_fast(self, question: str, search_results: List[SearchResult]) -> Tuple[str, List]:
        """고속 단답형 파이프라인 - 기존 로직 완전 유지"""
        if not search_results:
            log_message("SHORT 파이프라인: 검색 결과 없음")
            return "정보 부족", []
        
        # BM25 점수 기반 동적 청크 개수 결정
        bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
        bm25_max_score = max(bm25_scores) if bm25_scores else 0
        
        # 조문 참조 질문 감지 및 컨텍스트 확장
        is_article_ref = "제" in question and "조에서" in question
        
        # 동적 청크 개수 결정
        if bm25_max_score > 100:
            chunk_count = 5
        elif is_article_ref:
            chunk_count = 4
        else:
            chunk_count = 3
        
        log_message(f"SHORT 파이프라인: {chunk_count}개 청크 선택 (BM25최고:{bm25_max_score:.1f})")
        
        # 청크 점수 계산
        patterns = self._extract_question_patterns(question)
        
        scored_chunks = []
        for result in search_results:
            pattern_score = self._calculate_pattern_score(result.content, patterns)
            search_score = result.metadata.get('final_score', result.score)
            
            if is_article_ref:
                final_score = pattern_score * 0.7 + search_score * 0.3
            else:
                final_score = pattern_score * 0.5 + search_score * 0.5
            
            scored_chunks.append((result, final_score))
        
        # 점수순 정렬
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        top_chunks = scored_chunks[:chunk_count]
        
        # 컨텍스트 구성
        context_parts = []
        for i, (chunk, score) in enumerate(top_chunks, 1):
            context_parts.append(chunk.content)
        
        full_context = "\n".join(context_parts)
        
        # LLM 호출
        predicted = self.llm.call_short(question, full_context)
        
        log_message(f"SHORT 파이프라인 완료: '{predicted}'")
        return predicted, top_chunks

    def _extract_question_patterns(self, query: str) -> Dict[str, List[str]]:
        """질문 패턴 추출"""
        legal_patterns = {
            'articles': r'제\s*\d+\s*조(?:제\s*\d+\s*항)?(?:제\s*\d+\s*호)?',
            'periods': r'\d+\s*(?:년|개월|일)(?:\s*(?:이내|이상|미만))?',
            'amounts': r'\d+\s*(?:억|만)?\s*원(?:\s*(?:이상|이하|미만))?',
            'agencies': r'[가-힣]+(?:위원회|청|부|처|원)(?:장관?)?',
            'forms': r'별지\s*제\s*\d+\s*호(?:서식)?',
            'procedures': r'(?:신청|허가|승인|등록|신고|접수|처리|발급|제출)(?:서|절차|방법)?'
        }
        
        patterns = {}
        pattern_count = 0
        for pattern_name, pattern_regex in legal_patterns.items():
            matches = re.findall(pattern_regex, query)
            if matches:
                patterns[pattern_name] = matches
                pattern_count += len(matches)
        
        general_keywords = re.findall(r'[가-힣]{2,}', query)
        if general_keywords:
            patterns['keywords'] = general_keywords
        
        if pattern_count > 0:
            log_message(f"패턴 추출: {pattern_count}개")
        
        return patterns

    def _assess_context_quality(self, context: str, question: str) -> float:
        """컨텍스트 품질 평가"""
        if not context or len(context.strip()) < 20:
            return 0.0
        
        # 질문 키워드 추출
        question_keywords = set(re.findall(r'[가-힣]{3,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', question))
        context_keywords = set(re.findall(r'[가-힣]{3,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', context))
        
        if not question_keywords:
            return 0.5
        
        # 키워드 매칭률
        overlap = len(question_keywords & context_keywords)
        keyword_score = overlap / len(question_keywords) if question_keywords else 0
        
        # 컨텍스트 길이 점수
        if 100 <= len(context) <= 1000:
            length_score = 1.0
        elif 50 <= len(context) < 100 or 1000 < len(context) <= 2000:
            length_score = 0.7
        else:
            length_score = 0.3
        
        # 법령 패턴 점수
        legal_count = sum(1 for pattern in ['제', '조', '항', '호', '법률'] if pattern in context)
        legal_score = min(1.0, legal_count / 3)
        
        return min(1.0, keyword_score * 0.5 + length_score * 0.3 + legal_score * 0.2)

    def _count_pattern_matches(self, context: str, question: str) -> int:
        """패턴 매칭 개수 계산"""
        if not context or not question:
            return 0
        
        patterns = []
        patterns.extend(re.findall(r'제\s*\d+\s*조', question))
        patterns.extend(re.findall(r'\d+(?:년|개월|일)', question))
        patterns.extend(re.findall(r'\d+(?:억|만)?원', question))
        patterns.extend(re.findall(r'[가-힣]+(?:위원회|청|부|처|원)', question))
        
        return sum(1 for pattern in patterns if pattern in context)

    def _calculate_pattern_score(self, content: str, patterns: Dict[str, List[str]]) -> float:
        """패턴 점수 계산"""
        if not patterns:
            return 1.0
        
        score = 1.0
        if 'articles' in patterns:
            score += sum(2.0 for article in patterns['articles'] if article in content)
        if 'periods' in patterns:
            score += sum(1.5 for period in patterns['periods'] if period in content)
        if 'agencies' in patterns:
            score += sum(1.2 for agency in patterns['agencies'] if agency in content)
        if 'keywords' in patterns:
            matches = sum(1 for keyword in patterns['keywords'] if keyword in content)
            if patterns['keywords']:
                score += matches / len(patterns['keywords'])
        
        return score

    def _normalize_legal_answer(self, text: str) -> str:
        """법령 답변 정규화"""
        if not text:
            return ""
        
        text = str(text).strip()
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'제\s*(\d+)\s*조', r'제\1조', text)
        text = re.sub(r'(\d+)\s*(년|개월|일)', r'\1\2', text)
        text = re.sub(r'(\d+)\s*(억|만)?\s*원', r'\1\2원', text)
        
        for phrase in ['답변:', '답:', '정답:', '결론:', '따라서']:
            text = text.replace(phrase, '')
        
        return text.strip()

    def _print_summary(self, results: Dict[str, Any]):
        """평가 결과 요약 출력"""
        total_q = results.get('total_questions', 0)
        mcq_acc = results.get('mcq_accuracy', 0)
        short_em = results.get('short_em', 0)
        short_f1 = results.get('short_f1', 0)
        total_time = results.get('total_time', 0)
        
        log_message("="*50)
        log_message(f"총 문제: {total_q}, MCQ: {mcq_acc:.1%}, EM: {short_em:.1%}, F1: {short_f1:.1%}, 시간: {total_time:.1f}초")
        log_message("="*50)

    def save_results(self, results: Dict[str, Any], output_file: str = None, source_file: str = None) -> str:
        """결과 저장"""
        try:
            from rag.utils import save_evaluation_results
            return save_evaluation_results(results, output_file)
        except Exception as e:
            log_message(f"결과 저장 오류: {e}")
            return None