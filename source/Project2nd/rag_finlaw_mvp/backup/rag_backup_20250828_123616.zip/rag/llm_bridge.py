"""
llm_bridge.py - 2차 개선 버전 (로그 시스템 완전 통합)
핵심 개선: choice_mapping 오류 해결, 답변 정제 강화, 부정형 질문 처리 개선 
"""
import json
import time
import re
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import streamlit as st

def log_message(message):
    """로그 출력 - 웹 인터페이스와 콘솔"""
    print(f"[LLM] {message}")  # 콘솔 출력
    if hasattr(st.session_state, 'global_log_callback') and st.session_state.global_log_callback:
        # 웹 인터페이스 로그
        st.session_state.global_log_callback("progress", message, "LLM")

class HybridLLM:
    """2차 개선된 LLM Bridge"""
    
    def __init__(self, config):
        log_message("2차 개선된 LLM Bridge 초기화 중...")
        self.config = config
        self._init_llms()
        self._init_prompts()
        
        # 성능 추적
        self.performance_stats = {
            'mcq_choice_analysis_used': 0,
            'context_prioritization_used': 0,
            'answer_refinement_applied': 0,
            'high_confidence_warnings': 0,
            'total_calls': 0
        }
        
        log_message("LLM Bridge 초기화 완료")

    def _init_llms(self):
        """LLM 초기화"""
        self.clients = {}
        
        if self.config.openai_api_key:
            try:
                import openai
                self.clients['openai'] = openai.OpenAI(
                    api_key=self.config.openai_api_key,
                    timeout=self.config.llm_timeout
                )
                log_message("OpenAI 초기화 완료")
            except Exception as e:
                log_message(f"OpenAI 초기화 실패: {e}")
        
        if self.config.upstage_api_key:
            try:
                import openai
                self.clients['upstage'] = openai.OpenAI(
                    api_key=self.config.upstage_api_key,
                    base_url="https://api.upstage.ai/v1",
                    timeout=self.config.llm_timeout
                )
                log_message("Upstage 초기화 완료")
            except Exception as e:
                log_message(f"Upstage 초기화 실패: {e}")
        
        try:
            import requests
            response = requests.get(f"{self.config.ollama_base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                self.clients['ollama'] = True
                log_message("Ollama 연결 완료")
        except Exception as e:
            log_message(f"Ollama 연결 실패: {e}")
        
        if not self.clients:
            log_message("사용 가능한 LLM이 없음")

    def _init_prompts(self):
        """개선된 프롬프트 시스템"""
        self.prompts = {
            # MCQ 개선: 단계별 검증 강화
            'mcq_system_enhanced': """한국 법령 전문가로서 주어진 컨텍스트에서 정답을 선택하세요.

**필수 검증 절차 (반드시 순서대로):**

1단계: 각 선택지 검증
- A번 내용이 컨텍스트에 구체적으로 언급되어 있습니까? (예/아니오)
- B번 내용이 컨텍스트에 구체적으로 언급되어 있습니까? (예/아니오)  
- C번 내용이 컨텍스트에 구체적으로 언급되어 있습니까? (예/아니오)
- D번 내용이 컨텍스트에 구체적으로 언급되어 있습니까? (예/아니오)

2단계: 언급된 선택지들 중에서 질문에 가장 정확히 부합하는 것 선택

3단계: 최종 확인
- 선택한 답이 컨텍스트에서 명확히 확인됩니까?
- 다른 선택지보다 더 확실한 근거가 있습니까?

**핵심 원칙:**
- 컨텍스트에 없는 내용은 절대 선택 금지
- 추측하지 말고 명시된 내용만 근거로 사용
- 애매하면 가장 구체적인 근거가 있는 선택지 선택

최종 답변은 반드시 A, B, C, D 중 하나만 출력하세요.""",

            # 부정형 더 명확하게
            'mcq_negative_enhanced': """한국 법령 전문가입니다. 이는 부정형 질문입니다.

**부정형 질문 해결법:**
1. 컨텍스트에서 관련 내용을 모두 찾으세요
2. 각 선택지를 하나씩 확인하세요:
- A번: 이 내용이 컨텍스트에 언급되어 있으면 → 틀린 답
- B번: 이 내용이 컨텍스트에 언급되어 있으면 → 틀린 답  
- C번: 이 내용이 컨텍스트에 언급되어 있으면 → 틀린 답
- D번: 이 내용이 컨텍스트에 언급되어 있으면 → 틀린 답

3. **컨텍스트에 언급되지 않은 유일한 선택지가 정답입니다**

부정형에서는 "포함되지 않는" 것을 찾으므로, 컨텍스트에 없는 선택지를 선택해야 합니다.

반드시 A, B, C, D 중 하나만 출력하세요.""",

            'mcq_user': """컨텍스트:
{context}

질문: {question}

선택지:
A) {choice_a}
B) {choice_b}
C) {choice_c}
D) {choice_d}

답:""",

            # 단답형 핵심 개선: 질문에 직접 답하는 부분만 추출
            'short_general_enhanced': """법령 문서에서 질문에 직접 답하는 핵심만 추출하세요.

**추출 방법:**
1. 컨텍스트에서 관련 문장을 찾으세요
2. 그 문장에서 질문에 직접 답하는 핵심 부분만 추출하세요
3. 설명 부분은 제외하세요

**질문 유형별 추출:**
▶ 조문 질문 ("어느 조", "몇 조"): "제X조"만
▶ 담당자 질문 ("누가", "담당"): 기관명/직책명만  
▶ 기간 질문 ("언제", "기간"): 날짜/기간만
▶ 방식 질문 ("어떻게", "방식"): 핵심 방법만

**추출 예시:**
- 컨텍스트: "채권은 무기명식으로 발행한다"
- 질문: "발행 방식은?" → "무기명식" (O)
- 잘못: "채권은 무기명식으로 발행한다" (X)

- 컨텍스트: "다음 영업일 자정까지 제출한다"  
- 질문: "제출 시한은?" → "다음 영업일 자정" (O)
- 잘못: "다음 영업일 자정까지 제출한다" (X)

질문에 대한 직접적인 답변 부분만 추출하세요.""",

            'short_definition_enhanced': """법령에서 정의를 추출하는 전문가입니다.

"정의" 질문의 경우 해당 용어의 핵심 정의만 추출하세요.

**정의 추출 방법:**
1. "라 한다", "를 말한다" 앞의 핵심 정의 찾기
2. 조문 번호, "다음과 같다" 등 설명 제외  
3. 정의의 본질적 부분만 추출

**예시:**
- 전체: "제2조에서 중소기업이란 소규모 제조업체를 말한다"
- 추출: "소규모 제조업체" (O)

핵심 정의 내용만 추출하세요.""",

            'short_user': """컨텍스트:
{context}

질문: {question}

위 질문에 직접 답하는 핵심만 컨텍스트에서 추출:"""
        }

    def _analyze_question_intent(self, question: str) -> str:
        """질문 의도 분석"""
        if "정의는" in question or "정의를" in question or "정의한" in question:
            return "definition"
        elif ("내용 중" in question or "포함되는" in question or "요건" in question or 
              re.search(r'제\d+조에 따르면.*?(내용|항목|요건)', question)):
            return "content"
        elif "누가" in question or "담당" in question or "책임자" in question:
            return "person"
        elif "어느 조" in question or "몇 조" in question or "조문" in question:
            return "article"
        else:
            return "general"

    def _detect_negative_question_enhanced(self, question: str) -> bool:
        """강화된 부정형 질문 감지"""
        # 직접적 부정 표현 (더 포괄적)
        negative_indicators = [
            "포함되지 않는", "해당하지 않는", "맞지 않는", "아닌 것",
            "제외되는", "틀린 것", "잘못된 것", "해당되지 않는",
            "관련이 없는", "부적절한", "적합하지 않은", "불가능한",
            "위반되는", "위배되는", "어긋나는", "예외", "제외",
            "없는 것", "아닌 경우", "제외한", "빼고"
        ]
        
        # 문맥적 부정 패턴 (강화)
        contextual_patterns = [
            r"다음.*?중.*?(?:아닌|않은|없는|제외)",
            r"(?:포함|해당).*?(?:않|안)",
            r"적용.*?(?:되지 않|안 됨|제외)",
            r"다음.*?(?:제외|빼고|아닌)",
            r"어느.*?것.*?(?:아닌|않은)"
        ]
        
        # 직접적 부정어 검사
        for indicator in negative_indicators:
            if indicator in question:
                log_message(f"부정형 질문 감지: '{indicator}'")
                return True
        
        # 문맥적 패턴 검사
        for pattern in contextual_patterns:
            if re.search(pattern, question):
                log_message(f"부정형 패턴 감지: '{pattern}'")
                return True
        
        return False

    def _calculate_choice_confidence_score(self, context: str, question: str, choices: Dict[str, str]) -> Dict[str, float]:
        """선택지별 신뢰도 점수 계산"""
        confidence_scores = {}
        
        # 질문에서 핵심 키워드 추출
        question_keywords = set(re.findall(r'[가-힣]{3,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', question))
        
        for choice_key, choice_text in choices.items():
            # 선택지 키워드 추출
            choice_keywords = set(re.findall(r'[가-힣]{3,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', choice_text))
            
            if not choice_keywords:
                confidence_scores[choice_key] = 0.0
                continue
            
            # 1. 키워드 매칭 점수
            keyword_overlap = len(question_keywords & choice_keywords) / len(choice_keywords) if choice_keywords else 0
            
            # 2. 컨텍스트 내 구체적 매칭 점수
            context_match_score = 0.0
            for keyword in choice_keywords:
                if keyword in context:
                    # 정확한 문장에서 발견되는지 확인
                    sentences = re.split(r'[.!?]\s+', context)
                    for sentence in sentences:
                        if keyword in sentence and len(sentence) > 20:
                            context_match_score += 0.3
                            break
            
            # 3. 법령 패턴 보너스
            legal_bonus = 0.0
            if re.search(r'제\d+조', choice_text) and re.search(r'제\d+조', context):
                legal_bonus = 0.2
            
            # 최종 신뢰도 점수
            total_score = (keyword_overlap * 0.4 + context_match_score * 0.4 + legal_bonus)
            confidence_scores[choice_key] = min(1.0, total_score)
        
        return confidence_scores

    def _enhanced_context_analysis(self, context: str, question: str, choices: Dict[str, str]) -> str:
        """강화된 컨텍스트 분석 및 우선순위"""
        if len(context) < 2000:
            return context
        
        sentences = re.split(r'[.!?]\s+', context)
        if len(sentences) < 5:
            return context
        
        log_message(f"컨텍스트 재정렬 시작 (원본: {len(sentences)}문장)")
        
        # 질문 + 모든 선택지 키워드
        all_keywords = set()
        all_keywords.update(re.findall(r'[가-힣]{4,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', question))
        
        for choice in choices.values():
            choice_keywords = re.findall(r'[가-힣]{4,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', choice)
            all_keywords.update(choice_keywords[:2])  # 각 선택지에서 최대 2개만
        
        # 문장별 관련도 점수 계산
        scored_sentences = []
        for i, sent in enumerate(sentences):
            if len(sent.strip()) < 15:
                continue
            
            sent_keywords = set(re.findall(r'[가-힣]{4,}|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조', sent))
            overlap_score = len(all_keywords & sent_keywords)
            
            # 법령 패턴 보너스 (보수적)
            legal_bonus = 0
            if re.search(r'제\s*\d+\s*조', sent):
                legal_bonus = 1
            if re.search(r'\d+(?:년|개월|일)', sent):
                legal_bonus += 0.5
            
            # 위치 보너스 (원본 순서 고려)
            position_bonus = 0.1 if i < len(sentences) // 3 else 0
            
            total_score = overlap_score + legal_bonus + position_bonus
            scored_sentences.append((sent.strip(), total_score, i))
        
        # 점수순 정렬하되 원본 순서 고려
        scored_sentences.sort(key=lambda x: (-x[1], x[2]))
        
        # 상위 문장들 선별하여 재구성
        high_priority = [s[0] for s in scored_sentences[:3] if s[1] > 0.5]
        medium_priority = [s[0] for s in scored_sentences[3:6] if s[1] > 0]
        remaining = [s[0] for s in scored_sentences[6:]]
        
        reordered_sentences = high_priority + medium_priority + remaining
        
        self.performance_stats['context_prioritization_used'] += 1
        log_message(f"컨텍스트 재정렬 완료 (우선순위: {len(high_priority)}문장)")
        
        return ". ".join(reordered_sentences)

    def call_mcq(self, question: str, choices: Dict[str, str], context: str) -> str:
        """강화된 MCQ 처리"""
        
        self.performance_stats['total_calls'] += 1
        log_message("MCQ 처리 시작")
        
        # 부정형 질문 감지 (강화됨)
        is_negative = self._detect_negative_question_enhanced(question)
        
        # 선택지별 신뢰도 점수 계산
        confidence_scores = self._calculate_choice_confidence_score(context, question, choices)
        max_confidence = max(confidence_scores.values()) if confidence_scores else 0.0
        high_confidence_count = sum(1 for score in confidence_scores.values() if score >= 0.7)
        
        # 강화된 컨텍스트 분석
        enhanced_context = self._enhanced_context_analysis(context, question, choices)
        
        # 고신뢰도 경고 (더 엄격한 기준)
        if high_confidence_count >= 3 and max_confidence >= 0.8:
            self.performance_stats['high_confidence_warnings'] += 1
            log_message(f"경고: 다수 선택지 고신뢰도({high_confidence_count}개) - 매우 신중한 판단 필요")
        
        # 로깅 (기존 유지하되 신뢰도 점수 추가)
        question_type = "부정형" if is_negative else "일반형"
        log_message(f"{question_type} 질문, {'강화된' if is_negative else '향상된'} 프롬프트 사용")
        log_message(f"선택지신뢰도: A={confidence_scores.get('A', 0):.2f} B={confidence_scores.get('B', 0):.2f} "
              f"C={confidence_scores.get('C', 0):.2f} D={confidence_scores.get('D', 0):.2f} (최고:{max_confidence:.2f})")
        
        # 프롬프트 선택 (강화된 버전)
        if is_negative:
            system_prompt = self.prompts['mcq_negative_enhanced']
        else:
            system_prompt = self.prompts['mcq_system_enhanced']
        
        user_prompt = self.prompts['mcq_user'].format(
            context=enhanced_context,
            question=question,
            choice_a=choices.get('A', ''),
            choice_b=choices.get('B', ''),
            choice_c=choices.get('C', ''),
            choice_d=choices.get('D', '')
        )
        
        try:
            response = self._call_llm(system_prompt, user_prompt)
            log_message(f"MCQ 응답 완료: '{response.strip()}'")
            return response.strip()
        except Exception as e:
            log_message(f"MCQ 처리 오류: {e}")
            return "A"  # 기본값

    def call_short(self, question: str, context: str) -> str:
        """강화된 단답형 처리"""
        log_message("단답형 처리 시작")
        
        if not context or len(context.strip()) < 20:
            log_message("컨텍스트 부족으로 처리 불가")
            return "정보 부족"
        
        intent = self._analyze_question_intent(question)
        log_message(f"질문 의도 분석: {intent}")
        
        # 강화된 프롬프트 사용
        if intent == "definition":
            system_prompt = self.prompts['short_definition_enhanced']
        else:
            system_prompt = self.prompts['short_general_enhanced']
        
        user_prompt = self.prompts['short_user'].format(
            context=context,
            question=question
        )
        
        try:
            response = self._call_llm(system_prompt, user_prompt)
            
            if self._validate_response(response):
                processed = self._enhanced_post_process_response(response, intent, question)
                log_message(f"단답형 처리 완료: '{processed}'")
                return processed
            else:
                log_message("응답 검증 실패")
                return "정보 부족"
            
        except Exception as e:
            log_message(f"단답형 처리 오류: {e}")
            return "처리 실패"

    def _enhanced_post_process_response(self, response: str, intent: str, question: str) -> str:
        """강화된 답변 후처리"""
        if not response or "정보 부족" in response:
            return response
        
        self.performance_stats['answer_refinement_applied'] += 1
        log_message(f"답변 정제 시작 (의도: {intent})")
        
        response = response.strip()
        
        # 1. 기본 정리
        prefixes = ["답변:", "답:", "정답:", "결론:", "따라서", "그러므로", "추출:", "결과:", "위 질문의 답은"]
        for prefix in prefixes:
            if response.startswith(prefix):
                response = response[len(prefix):].strip()
        
        # 따옴표 제거
        if (response.startswith('"') and response.endswith('"')) or (response.startswith("'") and response.endswith("'")):
            response = response[1:-1].strip()
        
        # 2. 의도별 정밀 처리
        if intent == "article":
            # 조문: 제X조 패턴만 추출
            article_match = re.search(r'제\s*\d+\s*조(?:제\s*\d+\s*항)?', response)
            if article_match:
                result = article_match.group()
                log_message(f"조문 추출: '{result}'")
                return result
        
        elif intent == "person":
            # 담당자: 기관명+직책 또는 직책만
            person_patterns = [
                r'([가-힣]+(?:부|청|원|위원회))(?:장관?)?',
                r'([가-힣]+장관)',
                r'([가-힣]+위원장)'
            ]
            for pattern in person_patterns:
                match = re.search(pattern, response)
                if match:
                    result = match.group()
                    log_message(f"담당자 추출: '{result}'")
                    return result
        
        elif intent == "definition":
            # 정의: 핵심 정의문만 (더 정교하게)
            # "라 한다", "를 말한다" 앞의 내용 추출
            def_patterns = [
                r'["\'"]?([^"\']{10,40})["\'"]?(?:\s*라\s*한다|\s*를\s*말한다)',
                r'([가-힣\s]{8,30})(?:\s*라\s*한다|\s*를\s*말한다)',
                r'["\'"]([^"\']+)["\'"]'
            ]
            
            for pattern in def_patterns:
                match = re.search(pattern, response)
                if match:
                    definition = match.group(1).strip()
                    if len(definition) > 5:
                        # 8단어 이내로 제한
                        words = re.findall(r'[가-힣]+|\d+', definition)
                        if len(words) > 8:
                            definition = " ".join(words[:8])
                        log_message(f"정의 추출: '{definition}'")
                        return definition
        
        elif intent == "content" or "내용" in question:
            # "내용" 질문: 핵심 개념/용어만 추출
            content_patterns = [
                r'([가-힣]+(?:비중|비율|기준|요건|조건))',  # 비중, 비율 등
                r'([가-힣]+(?:시스템|방법|절차|과정))',     # 시스템, 방법 등
                r'([가-힣]{3,8}(?:업무|사업|활동))',        # 업무 관련
            ]
            
            for pattern in content_patterns:
                match = re.search(pattern, response)
                if match:
                    result = match.group(1)
                    log_message(f"내용 추출: '{result}'")
                    return result
        
        # 3. 일반적 길이 제어 (8단어 기준)
        words = re.findall(r'[가-힣]+|\d+(?:년|개월|일)|\d+(?:억|만)?원|제\d+조|\d+', response)
        
        if len(words) > 10:  # 10단어 초과시에만 단축
            # 질문 타입별 우선 키워드 식별
            priority_words = []
            
            if "누가" in question or "담당" in question:
                # 기관명 우선
                for word in words:
                    if re.match(r'[가-힣]+(?:부|청|원|위원회)', word):
                        priority_words.append(word)
                        break  # 첫 번째만
            
            elif "무엇" in question:
                # 핵심 명사 우선 (길이 제한)
                for word in words[:5]:  # 처음 5개에서만 찾기
                    if len(word) >= 3 and not re.match(r'\d+', word):
                        priority_words.append(word)
                        if len(priority_words) >= 3:  # 최대 3개
                            break
            
            elif "기간" in question or "언제" in question:
                # 기간 관련 우선
                for word in words:
                    if re.match(r'\d+(?:년|개월|일)', word):
                        priority_words.append(word)
            
            elif "금액" in question or "얼마" in question:
                # 금액 관련 우선  
                for word in words:
                    if re.match(r'\d+(?:억|만)?원', word):
                        priority_words.append(word)
            
            elif "조문" in question or "어느 조" in question:
                # 조문 우선
                for word in words:
                    if re.match(r'제\d+조', word):
                        priority_words.append(word)
            
            if priority_words:
                # 우선 키워드 + 주변 맥락
                result_words = priority_words + [w for w in words if w not in priority_words]
                response = " ".join(result_words[:8])
            else:
                # 일반적인 경우 앞의 8단어
                response = " ".join(words[:8])
        
        # 4. 불필요한 suffix 제거
        response = re.sub(r'(?:라\s*한다|를\s*말한다|에\s*따라|로\s*정한다)$', '', response)
        response = re.sub(r'[.!?]+$', '', response)
        
        final_result = response.strip() if response and len(response.strip()) > 1 else "정보 부족"
        log_message(f"후처리 완료: '{final_result}'")
        return final_result

    def _validate_response(self, response: str) -> bool:
        """응답 품질 검증"""
        if not response or len(response.strip()) <= 1:
            return False
        
        response = response.strip()
        
        if "정보 부족" in response:
            return True
        
        if len(response) <= 2:
            return False
        
        meaningless_patterns = [
            r'^[가-힣]{1,3}$',
            r'^[가-힣]로$', 
            r'^[가-힣]부$',
            r'^다음$',
            r'^해당$'
        ]
        
        for pattern in meaningless_patterns:
            if re.match(pattern, response):
                return False
        
        return True

    def _call_openai(self, messages: List[Dict]) -> str:
        """OpenAI API 호출"""
        response = self.clients['openai'].chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.0,
            max_tokens=self.config.max_tokens
        )
        return response.choices[0].message.content

    def _call_upstage(self, messages: List[Dict]) -> str:
        """Upstage API 호출"""
        response = self.clients['upstage'].chat.completions.create(
            model="solar-mini",
            messages=messages,
            temperature=0.0,
            max_tokens=self.config.max_tokens
        )
        return response.choices[0].message.content

    def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """LLM 호출 - 우선순위 기반"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # OpenAI 우선 시도
        if 'openai' in self.clients:
            try:
                result = self._call_openai(messages)
                log_message("OpenAI 호출 성공")
                return result
            except Exception as e:
                log_message(f"OpenAI 호출 실패: {e}")
        
        # Upstage 대안
        if 'upstage' in self.clients:
            try:
                result = self._call_upstage(messages)
                log_message("Upstage 호출 성공")
                return result
            except Exception as e:
                log_message(f"Upstage 호출 실패: {e}")
        
        log_message("모든 LLM 서비스 호출 실패")
        raise RuntimeError("모든 LLM 서비스 사용 불가")

    def get_performance_stats(self) -> Dict[str, Any]:
        """성능 통계 반환"""
        if self.performance_stats['total_calls'] > 0:
            return {
                'total_calls': self.performance_stats['total_calls'],
                'context_prioritization_rate': self.performance_stats['context_prioritization_used'] / self.performance_stats['total_calls'],
                'answer_refinement_rate': self.performance_stats['answer_refinement_applied'] / max(1, self.performance_stats['total_calls']),
                'high_confidence_warning_rate': self.performance_stats['high_confidence_warnings'] / max(1, self.performance_stats['total_calls'])
            }
        return self.performance_stats