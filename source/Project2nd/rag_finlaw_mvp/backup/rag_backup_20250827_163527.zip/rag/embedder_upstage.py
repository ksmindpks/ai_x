"""
간소화된 Upstage 임베딩 서비스 - 차원 자동 감지
"""
import os
import requests
import time
from typing import List, Dict, Any

class UpstageEmbedder:
    """간소화된 Upstage 임베딩 서비스"""
    
    def __init__(self, api_key: str = None, model: str = "embedding-query"):
        self.api_key = api_key or os.getenv("UPSTAGE_API_KEY")
        if not self.api_key:
            raise ValueError("UPSTAGE_API_KEY 환경변수가 설정되지 않았습니다")
            
        self.model = model
        self.api_url = "https://api.upstage.ai/v1/embeddings"
        
        # 차원 자동 감지용
        self._embedding_dim = None
        self._last_request_time = 0
        self._min_interval = 0.05  # 50ms
        
    def _rate_limit(self):
        """간단한 rate limiting"""
        current_time = time.time()
        elapsed = current_time - self._last_request_time
        if elapsed < self._min_interval:
            time.sleep(self._min_interval - elapsed)
        self._last_request_time = time.time()

    def _call_api(self, texts: List[str]) -> List[List[float]]:
        """API 호출 - 예외 처리 제거"""
        self._rate_limit()
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "input": texts if isinstance(texts, list) else [texts]
        }

        response = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()  # 실패시 바로 exception
        
        result = response.json()
        embeddings = []
        
        for item in result["data"]:
            embedding = [float(x) for x in item["embedding"]]
            
            # 첫 번째 성공적인 임베딩으로 차원 자동 감지
            if self._embedding_dim is None:
                self._embedding_dim = len(embedding)
                print(f"[EMBEDDER] 차원 자동 감지: {self._embedding_dim}")
            
            embeddings.append(embedding)
        
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 임베딩"""
        if not text or not text.strip():
            # 빈 벡터 반환시 차원 사용
            dim = self._embedding_dim or 1536  # fallback
            return [0.0] * dim
        
        embeddings = self._call_api([text.strip()])
        return embeddings[0] if embeddings else [0.0] * (self._embedding_dim or 1536)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """여러 문서 배치 임베딩"""
        if not texts:
            return []
        
        # 빈 텍스트 처리
        clean_texts = []
        text_indices = []
        
        for i, text in enumerate(texts):
            if text and text.strip():
                clean_texts.append(text.strip())
                text_indices.append(i)
        
        if not clean_texts:
            dim = self._embedding_dim or 1536
            return [[0.0] * dim] * len(texts)
        
        # 배치 API 호출
        embeddings = self._call_api(clean_texts)
        
        # 원본 순서로 복원
        result = []
        embedding_idx = 0
        dim = self._embedding_dim or (len(embeddings[0]) if embeddings else 1536)
        
        for i in range(len(texts)):
            if i in text_indices:
                result.append(embeddings[embedding_idx])
                embedding_idx += 1
            else:
                result.append([0.0] * dim)
        
        return result

# 전역 인스턴스
_embedder = None

def get_embedder() -> UpstageEmbedder:
    global _embedder
    if _embedder is None:
        _embedder = UpstageEmbedder()
    return _embedder