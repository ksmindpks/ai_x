"""
evaluator.py - 평가 로깅 강화 및 상세 디버깅 버전
핵심 개선: 부정형 질문 감지 로깅, 상세 원인 분석, MCQ 오답 패턴 추적
"""
import time
import pandas as pd
import re
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Tuple

from rag.utils import (
    load_excel_data, save_evaluation_results,
    calculate_enhanced_exact_match, calculate_enhanced_f1_score,
    parse_mcq_answer, SearchResult
)

class UnifiedEvaluator:
    """로깅 강화 및 상세 디버깅이 추가된 평가기"""
    
    def __init__(self, config):
        print("[EVALUATOR] 평가기 초기화 중...")
        self.config = config
        
        # 핵심 컴포넌트 초기화
        from rag.hybrid_retriever import HybridRetriever
        from rag.llm_bridge import HybridLLM
        
        self.retriever = HybridRetriever(config)
        self.llm = HybridLLM(config)
        
        # 법령 용어 사전
        self.legal_synonyms = {
            "중기부": "중소벤처기업부",
            "금위": "금융위원회",
            "금감원": "금융감독원",
            "공정위": "공정거래위원회",
        }
        
        print("[EVALUATOR] 초기화 완료")

    def evaluate_mcq_batch(self, questions: List[Dict], max_questions: int = None) -> Tuple[float, List[Dict]]:
        """MCQ 배치 평가 - 상세 로깅 및 오답 분석 강화"""
        if max_questions:
            questions = questions[:max_questions]
        
        if not questions:
            return 0.0, []
        
        print(f"[MCQ] 평가 시작: {len(questions)}개 문제")
        start_time = time.time()
        
        correct = 0
        results = []
        
        # 오답 패턴 추적용
        error_patterns = {
            'search_failure': 0,    # BM25=0, 낮은 검색 점수
            'choice_mapping': 0,    # 검색 성공, LLM 매핑 실패
            'context_quality': 0,   # 컨텍스트 품질 문제
            'negative_detection': 0  # 부정형 질문 감지 실패
        }
        
        for i, q in enumerate(questions):
            item_start = time.time()
            
            # MCQ 검색: BM25(6) + Vector(4) = 8개
            search_results = self.retriever.search(q['question'], question_type="MCQ")
            
            # 검색 점수 분석
            bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
            vector_scores = [r.metadata.get('vector_contribution', 0) for r in search_results]
            bm25_max = max(bm25_scores) if bm25_scores else 0
            vec_max = max(vector_scores) if vector_scores else 0
            
            # 부정형 질문 감지 (로깅용)
            is_negative_question = self._detect_negative_question(q['question'])
            
            # 청크 품질 필터링
            filtered_results = self._filter_low_quality_chunks(search_results)
            
            # 컨텍스트 선택
            context = self._select_mcq_context_simple(q['question'], filtered_results)
            
            # LLM 처리
            choices_dict = {chr(65+i): choice for i, choice in enumerate(q['choices'])}
            llm_response = self.llm.call_mcq(q['question'], choices_dict, context)
            
            # 답변 파싱
            expected_format = q.get('answer_format', 'number')
            predicted = parse_mcq_answer(llm_response, expected_format)
            correct_answer = str(q.get('answer', '1')).strip()
            
            is_correct = (predicted == correct_answer)
            if is_correct:
                correct += 1
            else:
                # 오답 원인 분석
                error_type = self._analyze_mcq_error(
                    bm25_max, vec_max, context, q['question'], 
                    choices_dict, predicted, correct_answer, is_negative_question
                )
                error_patterns[error_type] += 1
            
            item_time = time.time() - item_start
            
            # 품질 지표 계산
            context_quality = self._assess_context_quality(context, q['question'])
            pattern_matches = self._count_pattern_matches(context, q['question'])
            
            # 강화된 로깅 - 부정형 감지 상태 포함
            filtered_count = len(filtered_results)
            original_count = len(search_results)
            filter_info = f"({filtered_count}/{original_count})" if filtered_count != original_count else ""
            
            question_type_str = "부정형" if is_negative_question else "일반형"
            
            if is_correct:
                # 정답일 때는 간단하게
                print(f"[MCQ-{i+1}] LLM:\"{predicted}\"→'{correct_answer}' O ({item_time:.1f}s)")
            else:
                # 오답일 때는 전체 로그 유지
                print(f"[MCQ-{i+1}] 검색:{len(search_results)}개{filter_info}(BM25={bm25_max:.2f},Vec={vec_max:.2f}) "
                    f"컨텍스트:{len(context)}자(품질={context_quality:.2f}) 패턴:{pattern_matches}개 "
                    f"유형:{question_type_str} LLM:\"{predicted}\"→'{correct_answer}' {'O' if is_correct else 'X'} ({item_time:.1f}s)")
            
            # 결과 저장
            results.append({
                'question': q['question'][:100],
                'predicted': predicted,
                'correct': correct_answer,
                'is_correct': is_correct,
                'choices': q['choices'],
                'context_preview': context[:150],
                'response_time': item_time,
                'llm_response': llm_response[:100],
                'bm25_max_score': bm25_max,
                'vector_max_score': vec_max,
                'context_length': len(context),
                'context_quality': context_quality,
                'pattern_matches': pattern_matches,
                'is_negative_question': is_negative_question,
                'question_type': question_type_str,
                'filtered_chunk_count': filtered_count,
                'original_chunk_count': original_count,
                'error_type': error_type if not is_correct else 'correct'
            })
        
        accuracy = correct / len(questions)
        total_time = time.time() - start_time
        
        # 오답 패턴 분석 출력
        total_errors = len(questions) - correct
        if total_errors > 0:
            print(f"[MCQ] 오답 패턴 분석:")
            for pattern, count in error_patterns.items():
                if count > 0:
                    percentage = (count / total_errors) * 100
                    print(f"  - {pattern}: {count}개 ({percentage:.1f}%)")
        
        print(f"[MCQ] 완료: {accuracy:.1%} ({correct}/{len(questions)}) - {total_time:.1f}초")
        return accuracy, results

    def _detect_negative_question(self, question: str) -> bool:
        """부정형 질문 감지 (로깅용)"""
        negative_indicators = [
            "포함되지 않는", "해당하지 않는", "맞지 않는", "아닌 것",
            "제외되는", "틀린 것", "잘못된 것", "예외"
        ]
        
        for indicator in negative_indicators:
            if indicator in question:
                return True
        
        # 문맥적 패턴
        if re.search(r"다음.*?중.*?(?:아닌|않은|없는)", question):
            return True
        
        return False

    def _analyze_mcq_error(self, bm25_max: float, vec_max: float, context: str, 
                          question: str, choices: Dict, predicted: str, 
                          correct: str, is_negative: bool) -> str:
        """MCQ 오답 원인 분석"""
        
        # 1. 검색 실패형 (BM25 < 5.0 이고 Vector도 낮음)
        if bm25_max < 5.0 and vec_max < 1.0:
            return 'search_failure'
        
        # 2. 부정형 질문 감지 실패 (부정형인데 일반형으로 처리된 경우)
        if is_negative and not self._check_negative_processing_in_context(context, choices):
            return 'negative_detection'
        
        # 3. 컨텍스트 품질 문제 (검색은 됐지만 품질이 낮음)
        context_quality = self._assess_context_quality(context, question)
        if context_quality < 0.4:
            return 'context_quality'
        
        # 4. 선택지 매핑 오류 (검색과 컨텍스트는 양호)
        return 'choice_mapping'

    def _check_negative_processing_in_context(self, context: str, choices: Dict) -> bool:
        """부정형 질문 처리가 제대로 되었는지 확인"""
        # 간단한 휴리스틱: 모든 선택지가 컨텍스트에 어느 정도 언급되어 있는지 확인
        mentioned_count = 0
        for choice_text in choices.values():
            choice_keywords = set(re.findall(r'[가-힣]{3,}', choice_text))
            context_keywords = set(re.findall(r'[가-힣]{3,}', context))
            
            if len(choice_keywords & context_keywords) > 0:
                mentioned_count += 1
        
        # 4개 중 3개 이상이 언급되면 부정형 처리가 필요했던 상황
        return mentioned_count >= 3

    def _filter_low_quality_chunks(self, search_results: List[SearchResult]) -> List[SearchResult]:
        """저품질 청크 필터링"""
        if not search_results:
            return search_results
        
        filtered = []
        
        for result in search_results:
            bm25_score = result.metadata.get('bm25_contribution', 0)
            vector_score = result.metadata.get('vector_contribution', 0)
            
            # 필터링 조건: BM25 < 1.0 AND Vector < 0.3 인 청크 제외
            if bm25_score < 1.0 and vector_score < 0.3:
                continue  # 제외
            
            # 추가 조건: 내용이 너무 짧은 청크 제외
            if len(result.content.strip()) < 50:
                continue  # 제외
            
            filtered.append(result)
        
        # 필터링 결과가 너무 적으면 원본 일부 복원
        if len(filtered) < 2 and len(search_results) > 0:
            # 상위 2개는 무조건 포함
            for result in search_results[:2]:
                if result not in filtered:
                    filtered.append(result)
        
        return filtered

    def _select_mcq_context_simple(self, question: str, search_results: List[SearchResult]) -> str:
        """MCQ 컨텍스트 선택"""
        if not search_results:
            return "관련 정보를 찾을 수 없습니다."
        
        # BM25 점수 확인
        bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
        bm25_max_score = max(bm25_scores) if bm25_scores else 0
        
        # 동적 청크 개수
        if bm25_max_score > 50:
            chunk_count = 4
        else:
            chunk_count = 3
        
        # 검색기 점수를 그대로 활용
        scored_chunks = []
        for result in search_results:
            score = result.metadata.get('final_score', result.score)
            scored_chunks.append((result, score))
        
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        selected_chunks = scored_chunks[:chunk_count]
        
        context_parts = []
        for i, (chunk, score) in enumerate(selected_chunks, 1):
            context_parts.append(f"[참고자료 {i}]\n{chunk.content}")
        
        return "\n\n".join(context_parts)

    def evaluate_short_batch(self, questions: List[Dict], max_questions: int = None) -> Tuple[float, float, List[Dict]]:
        """단답형 배치 평가 - 기존 코드 완전 유지"""
        if max_questions:
            questions = questions[:max_questions]
        
        if not questions:
            return 0.0, 0.0, []
        
        print(f"[SHORT] 평가 시작: {len(questions)}개 문제")
        start_time = time.time()
        
        em_correct = 0
        f1_total = 0.0
        results = []
        
        for i, q in enumerate(questions):
            item_start = time.time()
            
            # 단답형 검색: BM25(8) + Vector(2) = 10개
            search_results = self.retriever.search(q['question'], question_type="short")
            
            # 검색 점수 분석
            bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
            vector_scores = [r.metadata.get('vector_contribution', 0) for r in search_results]
            bm25_max = max(bm25_scores) if bm25_scores else 0
            vec_max = max(vector_scores) if vector_scores else 0
            
            # 기존 단답형 파이프라인 사용
            predicted, scored_chunks = self._process_short_pipeline_fast(q['question'], search_results)
            
            # 정답 비교
            correct_answer = str(q.get('answer', '정보부족')).strip()
            
            # 법령 용어 정규화
            predicted_normalized = self._normalize_legal_answer(predicted)
            correct_normalized = self._normalize_legal_answer(correct_answer)
            
            # EM/F1 계산
            em_score = calculate_enhanced_exact_match(predicted_normalized, correct_normalized)
            f1_score = calculate_enhanced_f1_score(predicted_normalized, correct_normalized)
            
            if em_score:
                em_correct += 1
            f1_total += f1_score
            
            item_time = time.time() - item_start
            
            # 품질 지표 계산
            bm25_max_for_chunks = max([r.metadata.get('bm25_contribution', 0) for r in search_results], default=0)
            is_article_ref = "제" in q['question'] and "조에서" in q['question']
            
            if bm25_max_for_chunks > 100:
                expected_chunk_count = 5
            elif is_article_ref:
                expected_chunk_count = 4
            else:
                expected_chunk_count = 3
            
            if scored_chunks and len(scored_chunks) >= expected_chunk_count:
                context_parts = [chunk.content for chunk, score in scored_chunks[:expected_chunk_count]]
                full_context = "\n".join(context_parts)
            else:
                full_context = "컨텍스트 없음"
            
            context_quality = self._assess_context_quality(full_context, q['question'])
            pattern_matches = self._count_pattern_matches(full_context, q['question'])
            extraction_success = "추출성공" if len(predicted.strip()) > 3 and "정보 부족" not in predicted else "추출실패"
            
            if em_score:
                # 정답일 때는 간단하게
                print(f"[SHORT-{i+1}] LLM:\"{predicted}\" EM=1.0 F1={f1_score:.2f} ({item_time:.1f}s)")
            else:
                # 오답일 때는 전체 로그 유지
                print(f"[SHORT-{i+1}] 검색:{len(search_results)}개(BM25={bm25_max:.2f},Vec={vec_max:.2f}) "
                    f"컨텍스트:{expected_chunk_count}개청크(품질={context_quality:.2f}) 패턴:{pattern_matches}개 "
                    f"추출:{extraction_success} LLM:\"{predicted}\" EM={1.0 if em_score else 0.0:.1f} F1={f1_score:.2f} ({item_time:.1f}s)")
            
            # 결과 저장
            results.append({
                'question': q['question'][:100],
                'predicted': predicted,
                'predicted_normalized': predicted_normalized,
                'correct': correct_answer,
                'correct_normalized': correct_normalized,
                'em_score': 1.0 if em_score else 0.0,
                'f1_score': f1_score,
                'pipeline_method': "debug_enhanced",
                'response_time': item_time,
                'bm25_max_score': bm25_max,
                'vector_max_score': vec_max,
                'context_quality': context_quality,
                'pattern_matches': pattern_matches,
                'extraction_success': extraction_success,
                'chunk_count_used': expected_chunk_count
            })
        
        em_avg = em_correct / len(questions)
        f1_avg = f1_total / len(questions)
        total_time = time.time() - start_time
        
        print(f"[SHORT] 완료: EM={em_avg:.1%}, F1={f1_avg:.1%} - {total_time:.1f}초")
        
        return em_avg, f1_avg, results

    # 기존 유틸리티 메서드들
    def _process_short_pipeline_fast(self, question: str, search_results: List[SearchResult]) -> Tuple[str, List]:
        """고속 단답형 파이프라인 - 기존 로직 완전 유지"""
        if not search_results:
            return "정보 부족", []
        
        # BM25 점수 기반 동적 청크 개수 결정
        bm25_scores = [r.metadata.get('bm25_contribution', 0) for r in search_results]
        bm25_max_score = max(bm25_scores) if bm25_scores else 0
        
        # 조문 참조 질문 감지 및 컨텍스트 확장
        is_article_ref = "제" in question and "조에서" in question
        
        # 동적 청크 개수 결정
        if bm25_max_score > 100:
            chunk_count = 5
        elif is_article_ref:
            chunk_count = 4
        else:
            chunk_count = 3
        
        # 청크 점수 계산
        patterns = self._extract_question_patterns(question)
        
        scored_chunks = []
        for result in search_results:
            pattern_score = self._calculate_pattern_score(result.content, patterns)
            search_score = result.metadata.get('final_score', result.score)
            
            if is_article_ref:
                final_score = pattern_score * 0.7 + search_score * 0.3
            else:
                final_score = pattern_score * 0.5 + search_score * 0.5
            
            scored_chunks.append((result, final_score))
        
        # 점수순 정렬
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        top_chunks = scored_chunks[:chunk_count]
        
        # LLM 답변 생성
        if not top_chunks:
            return "정보 부족", []
        
        context_parts = []
        for i, (chunk, score) in enumerate(top_chunks, 1):
            context_parts.append(f"참고자료 {i}:\n{chunk.content}")
        
        context = "\n\n".join(context_parts)
        
        try:
            final_answer = self.llm.call_short(question, context)
            result_answer = final_answer if final_answer and len(final_answer.strip()) > 1 else "정보 부족"
            return result_answer, scored_chunks
        except Exception:
            return "처리 실패", scored_chunks

    def _extract_question_patterns(self, query: str) -> Dict[str, List[str]]:
        """질문에서 패턴 추출"""
        return {
            'articles': re.findall(r'제\s*(\d+)\s*조', query),
            'periods': re.findall(r'(\d+)\s*(일|개월|년)', query),
            'forms': re.findall(r'별지\s*제\s*(\d+)\s*호', query),
            'amounts': re.findall(r'(\d+)\s*(억|만)?\s*원', query),
            'agencies': re.findall(r'([가-힣]+(?:위원회|청|부|처|원))', query),
            'keywords': re.findall(r'[가-힣]{2,}', query)
        }

    def _calculate_pattern_score(self, text: str, patterns: Dict) -> float:
        """패턴 매칭 점수 계산"""
        score = 0.0
        
        for article in patterns['articles']:
            if f"제{article}조" in text:
                score += 1.0
        
        for period, unit in patterns['periods']:
            if f"{period}{unit}" in text:
                score += 0.8
        
        for agency in patterns['agencies']:
            if agency in text:
                score += 0.6
        
        question_words = set(patterns['keywords'])
        text_words = set(re.findall(r'[가-힣]{2,}', text))
        
        if question_words:
            overlap_ratio = len(question_words & text_words) / len(question_words)
            score += overlap_ratio * 0.3
        
        return score

    def _normalize_legal_answer(self, answer: str) -> str:
        """법령 답변 정규화"""
        if not answer:
            return ""
        
        normalized = answer.strip()
        
        # 동의어 통일
        for synonym, standard in self.legal_synonyms.items():
            normalized = normalized.replace(synonym, standard)
        
        # 조문 정규화
        normalized = re.sub(r'제\s*(\d+)\s*조', r'제\1조', normalized)
        normalized = re.sub(r'(\d+)\s*(년|개월|일)', r'\1\2', normalized)
        normalized = re.sub(r'(\d+)\s*(억|만)?\s*원', r'\1\2원', normalized)
        
        return normalized

    def _assess_context_quality(self, context: str, question: str) -> float:
        """컨텍스트 품질 평가"""
        if not context:
            return 0.0
        
        quality = 0.0
        
        # 길이 적절성
        if 100 <= len(context) <= 1000:
            quality += 0.3
        elif len(context) > 1000:
            quality += 0.1
        
        # 질문 키워드 포함 여부
        question_words = set(re.findall(r'[가-힣]{2,}', question))
        context_words = set(re.findall(r'[가-힣]{2,}', context))
        
        if question_words:
            overlap_ratio = len(question_words & context_words) / len(question_words)
            quality += overlap_ratio * 0.4
        
        # 법령 패턴 포함 여부
        legal_patterns = [
            r'제\s*\d+\s*조',
            r'\d+(?:년|개월|일)',
            r'[가-힣]+(?:위원회|청|부|처|원)',
            r'\d+(?:억|만)?원'
        ]
        
        for pattern in legal_patterns:
            if re.search(pattern, context):
                quality += 0.1
        
        return min(quality, 1.0)

    def _count_pattern_matches(self, context: str, question: str) -> int:
        """패턴 매칭 개수 계산"""
        patterns = self._extract_question_patterns(question)
        matches = 0
        
        # 조문 매칭
        for article in patterns['articles']:
            if f"제{article}조" in context:
                matches += 1
        
        # 기간 매칭
        for period, unit in patterns['periods']:
            if f"{period}{unit}" in context:
                matches += 1
        
        # 기관 매칭
        for agency in patterns['agencies']:
            if agency in context:
                matches += 1
        
        return matches

    def evaluate_file(self, file_path: str, mcq_limit: int = None, short_limit: int = None) -> Dict[str, Any]:
        """전체 파일 평가"""
        print(f"[EVAL] 파일 평가: {Path(file_path).name}")
        
        eval_start_time = time.time()
        
        # 데이터 로드
        mcq_questions, short_questions = load_excel_data(file_path, mcq_limit, short_limit)
        
        if not mcq_questions and not short_questions:
            print("[EVAL] 평가할 질문이 없습니다.")
            return {}
        
        print(f"[EVAL] 데이터 로드: MCQ {len(mcq_questions)}개, 단답형 {len(short_questions)}개")
        
        # MCQ 평가
        mcq_accuracy = 0.0
        mcq_results = []
        if mcq_questions:
            mcq_accuracy, mcq_results = self.evaluate_mcq_batch(mcq_questions, mcq_limit)
        
        # 단답형 평가
        short_em = short_f1 = 0.0
        short_results = []
        if short_questions:
            short_em, short_f1, short_results = self.evaluate_short_batch(short_questions, short_limit)
        
        total_eval_time = time.time() - eval_start_time
        
        # 결과 정리
        evaluation_results = {
            'mcq_accuracy': mcq_accuracy,
            'short_em': short_em,
            'short_f1': short_f1,
            'mcq_total': len(mcq_results),
            'short_total': len(short_results),
            'total_questions': len(mcq_results) + len(short_results),
            'mcq_results': mcq_results,
            'short_results': short_results,
            'source_file': Path(file_path).name,
            'total_time': total_eval_time,
            'improvement_info': {
                'debug_logging_enhanced': True,
                'error_pattern_analysis': True,
                'negative_question_detection': True,
                'choice_relevance_calculation': True
            }
        }
        
        self._print_summary(evaluation_results)
        return evaluation_results

    def _print_summary(self, results: Dict[str, Any]):
        """결과 요약 출력"""
        print("\n" + "=" * 50)
        print("평가 결과 요약")
        print("=" * 50)
        
        if results.get('mcq_total', 0) > 0:
            mcq_correct = sum(1 for r in results.get('mcq_results', []) if r.get('is_correct', False))
            print(f"MCQ: {results['mcq_accuracy']:.1%} ({mcq_correct}/{results['mcq_total']})")
        
        if results.get('short_total', 0) > 0:
            print(f"단답형: EM={results['short_em']:.1%}, F1={results['short_f1']:.1%}")
        
        print(f"총 시간: {results.get('total_time', 0):.1f}초")
        print(f"평균: {results.get('total_time', 0)/max(1, results.get('total_questions', 1)):.1f}초/문제")

    def save_results(self, results: Dict[str, Any], output_file: str = None, source_file: str = "") -> str:
        """결과 저장"""
        return save_evaluation_results(results, output_file)