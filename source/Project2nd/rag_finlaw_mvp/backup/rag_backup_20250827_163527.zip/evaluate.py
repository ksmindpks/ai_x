"""
evaluate.py - 개선된 버전
핵심 개선사항:
1. EnhancedEvaluator 사용
2. 의미없는 성능 목표 메시지 제거
3. 실시간 진행 상황 모니터링
4. 간결하고 정확한 결과 출력
"""
import os
import sys
import argparse
from pathlib import Path
from dotenv import load_dotenv

# 환경변수 로드
load_dotenv()

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

def run_enhanced_evaluation(file_path: str, mcq_limit: int = None, short_limit: int = None):
    """개선된 평가 실행"""
    
    print(f"\n평가 시작: {file_path}")
    
    # 1. 파일 검증
    print("[1/4] 파일 검증...")
    file_path_obj = Path(file_path)
    if not file_path_obj.exists():
        print(f"오류: 파일을 찾을 수 없습니다: {file_path}")
        return False
    print("파일 검증 완료")
    
    # 2. 시스템 초기화
    print("[2/4] 시스템 초기화...")
    
    try:
        from config import get_config
        config = get_config()
        
        # 기존 평가기 사용 (UnifiedEvaluator)
        from rag.evaluator import UnifiedEvaluator
        evaluator = UnifiedEvaluator(config)
        print("시스템 초기화 완료")
        
    except Exception as e:
        print(f"오류: 시스템 초기화 실패 - {e}")
        return False
    
    # 3. 평가 실행
    print("[3/4] 평가 실행...")
    
    try:
        results = evaluator.evaluate_file(file_path, mcq_limit, short_limit)
        
        if not results:
            print("오류: 평가할 데이터가 없습니다.")
            return False
        
    except Exception as e:
        print(f"오류: 평가 실행 실패 - {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # 4. 결과 저장
    print("[4/4] 결과 저장...")
    
    try:
        saved_file = evaluator.save_results(results, None, file_path)
        
        if saved_file:
            print(f"결과 저장 완료: {saved_file}")
            return True
        else:
            print("결과 저장 실패")
            return False
            
    except Exception as e:
        print(f"오류: 결과 저장 실패 - {e}")
        return False

def main():
    """메인 함수"""
    parser = argparse.ArgumentParser(
        description="RAG 시스템 평가 도구",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python evaluate.py test.xlsx --mcq 5 --short 5
        """
    )
    
    parser.add_argument('file', nargs='?', help='평가할 Excel 파일 경로')
    parser.add_argument('--mcq', type=int, help='MCQ 문제 수 제한')
    parser.add_argument('--short', type=int, help='단답형 문제 수 제한')
    parser.add_argument('--debug', action='store_true', help='디버그 모드')
    
    args = parser.parse_args()
    
    if not args.file:
        print("오류: 평가할 파일 경로가 필요합니다.")
        sys.exit(1)
    
    # 디버그 모드 설정
    if args.debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)
        print("[DEBUG] 디버그 모드 활성화")
    
    try:
        success = run_enhanced_evaluation(
            file_path=args.file,
            mcq_limit=args.mcq,
            short_limit=args.short
        )
        
        if success:
            print("\n평가가 성공적으로 완료되었습니다!")
        else:
            print("\n평가 실패!")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n평가가 사용자에 의해 중단되었습니다.")
        sys.exit(1)
        
    except Exception as e:
        print(f"\n예상치 못한 오류 발생: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()