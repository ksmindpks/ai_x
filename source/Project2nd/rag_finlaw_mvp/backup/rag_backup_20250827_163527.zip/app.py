import streamlit as st
import os
import sys
import glob
import pandas as pd
from pathlib import Path
from datetime import datetime
import threading
import time
import queue
import traceback

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

try:
    from rag.retriever import retrieve
    from rag.generator import generate_answer_short, generate_answer_mcq
    from config import get_config
    RAG_AVAILABLE = True
except ImportError as e:
    st.error(f"RAG 모듈 import 실패: {e}")
    RAG_AVAILABLE = False

# 페이지 설정
st.set_page_config(
    page_title="통합 RAG 시스템", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if 'evaluation_running' not in st.session_state:
    st.session_state.evaluation_running = False
if 'progress_logs' not in st.session_state:
    st.session_state.progress_logs = []
if 'success_logs' not in st.session_state:
    st.session_state.success_logs = []
if 'failure_logs' not in st.session_state:
    st.session_state.failure_logs = []

def add_log(log_type, message):
    """로그 추가"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    
    if log_type == "progress":
        st.session_state.progress_logs.append(log_entry)
        if len(st.session_state.progress_logs) > 100:
            st.session_state.progress_logs.pop(0)
    elif log_type == "success":
        st.session_state.success_logs.append(log_entry)
    elif log_type == "failure":
        st.session_state.failure_logs.append(log_entry)

def get_excel_files():
    """루트 디렉토리의 Excel 파일 목록"""
    excel_patterns = ["*.xlsx", "*.xls"]
    excel_files = []
    
    for pattern in excel_patterns:
        files = glob.glob(str(project_root / pattern))
        excel_files.extend([Path(f).name for f in files])
    
    return sorted(excel_files)

def run_evaluation_thread(excel_file, mcq_limit, short_limit, progress_callback):
    """평가 실행 스레드"""
    try:
        progress_callback("progress", "평가 시스템 초기화 중...")
        
        # 평가 모듈 동적 import
        try:
            from rag.evaluator import UnifiedEvaluator
            config = get_config()
            evaluator = UnifiedEvaluator(config)
            progress_callback("progress", "평가 시스템 초기화 완료")
        except Exception as e:
            progress_callback("failure", f"평가 시스템 초기화 실패: {e}")
            return
        
        # 파일 경로 설정
        file_path = project_root / excel_file
        if not file_path.exists():
            progress_callback("failure", f"파일을 찾을 수 없음: {excel_file}")
            return
        
        progress_callback("progress", f"평가 파일 로드: {excel_file}")
        
        # 평가 실행
        try:
            # UnifiedEvaluator에 progress_callback이 지원되는지 확인 후 호출
            try:
                results = evaluator.evaluate_file(
                    str(file_path), 
                    mcq_limit=mcq_limit, 
                    short_limit=short_limit,
                    progress_callback=lambda msg: progress_callback("progress", msg)
                )
            except TypeError:
                # progress_callback을 지원하지 않는 경우
                progress_callback("progress", "progress_callback 미지원 - 기본 평가 실행")
                results = evaluator.evaluate_file(
                    str(file_path), 
                    mcq_limit, 
                    short_limit
                )
            
            if not results:
                progress_callback("failure", "평가할 데이터가 없습니다")
                return
            
            # 결과 저장
            saved_file = evaluator.save_results(results, None, str(file_path))
            
            if saved_file:
                progress_callback("success", f"평가 완료! 결과 저장: {Path(saved_file).name}")
                
                # 성공/실패 통계
                total_questions = len(results.get('mcq_results', [])) + len(results.get('short_results', []))
                success_count = sum(1 for r in results.get('mcq_results', []) if r.get('success', False))
                success_count += sum(1 for r in results.get('short_results', []) if r.get('success', False))
                
                progress_callback("success", f"전체 {total_questions}문제 중 {success_count}문제 성공")
                
                # 실패한 문제들 로그
                for result in results.get('mcq_results', []):
                    if not result.get('success', False):
                        question = result.get('question', 'Unknown')[:50] + "..."
                        error = result.get('error', 'Unknown error')
                        progress_callback("failure", f"MCQ 실패: {question} - {error}")
                
                for result in results.get('short_results', []):
                    if not result.get('success', False):
                        question = result.get('question', 'Unknown')[:50] + "..."
                        error = result.get('error', 'Unknown error')
                        progress_callback("failure", f"단답형 실패: {question} - {error}")
                        
            else:
                progress_callback("failure", "결과 저장 실패")
                
        except Exception as e:
            progress_callback("failure", f"평가 실행 중 오류: {str(e)}")
            progress_callback("failure", f"상세 오류: {traceback.format_exc()}")
            
    except Exception as e:
        progress_callback("failure", f"평가 스레드 오류: {str(e)}")
    
    finally:
        st.session_state.evaluation_running = False
        progress_callback("progress", "평가 완료")

def run_reindexing():
    """벡터 재생성"""
    add_log("progress", "벡터 재생성 시작...")
    try:
        # reindex_upstage_docx.py 실행
        import subprocess
        result = subprocess.run([
            sys.executable, 
            str(project_root / "reindex_upstage_docx.py")
        ], capture_output=True, text=True, timeout=3600)  # 1시간 타임아웃
        
        if result.returncode == 0:
            add_log("success", "벡터 재생성 완료")
            add_log("success", f"출력: {result.stdout[-200:]}")  # 마지막 200자만
        else:
            add_log("failure", f"벡터 재생성 실패: {result.stderr}")
            
    except subprocess.TimeoutExpired:
        add_log("failure", "벡터 재생성 타임아웃 (1시간 초과)")
    except Exception as e:
        add_log("failure", f"벡터 재생성 오류: {e}")

def rebuild_bm25():
    """BM25 인덱스 재생성"""
    add_log("progress", "BM25 인덱스 재생성 시작...")
    try:
        import subprocess
        result = subprocess.run([
            sys.executable,
            str(project_root / "pipeline_bm25_from_docx.py")
        ], capture_output=True, text=True, timeout=1800)  # 30분 타임아웃
        
        if result.returncode == 0:
            add_log("success", "BM25 인덱스 재생성 완료")
            add_log("success", f"출력: {result.stdout[-200:]}")
        else:
            add_log("failure", f"BM25 인덱스 재생성 실패: {result.stderr}")
            
    except subprocess.TimeoutExpired:
        add_log("failure", "BM25 인덱스 재생성 타임아웃 (30분 초과)")
    except Exception as e:
        add_log("failure", f"BM25 인덱스 재생성 오류: {e}")

# 사이드바 - 기능 선택
st.sidebar.title("금융법령 RAG 시스템")
st.sidebar.markdown("---")

tab_selection = st.sidebar.radio(
    "기능 선택",
    ["질의응답", "평가 시스템", "관리 도구"],
    index=0
)

# 메인 콘텐츠
if tab_selection == "질의응답":
    st.title("금융 법령 질의응답")
    st.caption("AI 기반 법령 질의응답 시스템")
    
    if not RAG_AVAILABLE:
        st.error("RAG 시스템을 사용할 수 없습니다. 모듈을 확인해주세요.")
        st.stop()
    
    # 질문 입력
    question = st.text_input("질문을 입력하세요", placeholder="예: 은행법 제1조의 목적은 무엇인가요?")
    
    # 사지선다형 옵션
    col1, col2 = st.columns([1, 3])
    with col1:
        is_mcq = st.checkbox("사지선다형")
    
    choices = []
    if is_mcq:
        st.subheader("선택지")
        cols = st.columns(2)
        for i in range(4):
            with cols[i % 2]:
                choice = st.text_input(f"보기 {i+1}", key=f"choice_{i}")
                if choice:
                    choices.append(choice)
    
    # 검색 및 답변
    if st.button("질문하기", type="primary", use_container_width=True):
        if not question:
            st.warning("질문을 입력해주세요")
        else:
            with st.spinner("검색 중..."):
                try:
                    contexts = retrieve(question, top_k=5)
                except Exception as e:
                    st.error(f"검색 오류: {e}")
                    st.stop()
            
            if not contexts:
                st.error("관련 문서를 찾을 수 없습니다")
            else:
                # 검색 결과 표시
                with st.expander("검색 결과", expanded=False):
                    for i, ctx in enumerate(contexts[:3], 1):
                        st.write(f"**[{i}]** Score: {ctx['score']:.3f}")
                        st.write(f"{ctx['text'][:200]}...")
                
                # 답변 생성
                with st.spinner("답변 생성 중..."):
                    try:
                        if is_mcq and choices:
                            answer = generate_answer_mcq(question, choices, contexts)
                        else:
                            answer = generate_answer_short(question, contexts)
                    except Exception as e:
                        st.error(f"답변 생성 오류: {e}")
                        st.stop()
                
                # 답변 표시
                st.success("답변")
                st.markdown(answer)

elif tab_selection == "평가 시스템":
    st.title("평가 시스템")
    st.caption("RAG 시스템 성능 평가 도구")
    
    if not RAG_AVAILABLE:
        st.error("RAG 시스템을 사용할 수 없습니다.")
        st.stop()
    
    # 평가 설정
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("평가 설정")
        
        # Excel 파일 선택
        excel_files = get_excel_files()
        if not excel_files:
            st.error("루트 디렉토리에 Excel 파일이 없습니다.")
            selected_file = None
        else:
            selected_file = st.selectbox(
                "평가할 Excel 파일",
                excel_files,
                help="루트 디렉토리의 Excel 파일 중 선택"
            )
        
        # 평가 옵션
        col_mcq, col_short = st.columns(2)
        with col_mcq:
            mcq_limit = st.number_input(
                "선다형 최대 문제 수",
                min_value=1,
                max_value=500,
                value=50,
                step=10
            )
        
        with col_short:
            short_limit = st.number_input(
                "단답형 최대 문제 수",
                min_value=1,
                max_value=500,
                value=50,
                step=10
            )
        
        # 평가 시작 버튼
        if st.button(
            "평가 시작", 
            type="primary", 
            disabled=st.session_state.evaluation_running or not selected_file,
            use_container_width=True
        ):
            if selected_file:
                st.session_state.evaluation_running = True
                st.session_state.progress_logs = []
                st.session_state.success_logs = []
                st.session_state.failure_logs = []
                
                # 평가 실행 (별도 스레드)
                def progress_callback(log_type, message):
                    add_log(log_type, message)
                
                thread = threading.Thread(
                    target=run_evaluation_thread,
                    args=(selected_file, mcq_limit, short_limit, progress_callback)
                )
                thread.daemon = True
                thread.start()
                
                st.success(f"평가 시작: {selected_file}")
                st.rerun()
    
    with col2:
        st.subheader("평가 상태")
        
        if st.session_state.evaluation_running:
            st.info("평가 진행 중...")
            progress_bar = st.progress(0)
            
            # 진행률 표시 (단순 애니메이션)
            if 'progress_value' not in st.session_state:
                st.session_state.progress_value = 0
            
            st.session_state.progress_value = (st.session_state.progress_value + 0.1) % 1.0
            progress_bar.progress(st.session_state.progress_value)
            
            if st.button("평가 중지"):
                st.session_state.evaluation_running = False
                add_log("progress", "사용자가 평가를 중지했습니다")
                st.rerun()
        else:
            st.success("평가 대기 중")
    
    # 로그 창들
    st.markdown("---")
    
    # 3개 컬럼으로 로그 창 배치
    log_col1, log_col2, log_col3 = st.columns(3)
    
    with log_col1:
        st.subheader("진행 상황")
        if st.session_state.progress_logs:
            log_text = "\n".join(st.session_state.progress_logs[-20:])  # 최근 20개만
            st.text_area("", value=log_text, height=300, key="progress_logs_area")
        else:
            st.text_area("", value="진행 로그가 없습니다.", height=300, key="progress_empty")
    
    with log_col2:
        st.subheader("성공 로그")
        if st.session_state.success_logs:
            log_text = "\n".join(st.session_state.success_logs[-20:])
            st.text_area("", value=log_text, height=300, key="success_logs_area")
        else:
            st.text_area("", value="성공 로그가 없습니다.", height=300, key="success_empty")
    
    with log_col3:
        st.subheader("실패 로그")
        if st.session_state.failure_logs:
            log_text = "\n".join(st.session_state.failure_logs[-20:])
            st.text_area("", value=log_text, height=300, key="failure_logs_area")
        else:
            st.text_area("", value="실패 로그가 없습니다.", height=300, key="failure_empty")
    
    # 자동 새로고침 (평가 진행 중일 때만)
    if st.session_state.evaluation_running:
        time.sleep(2)
        st.rerun()

elif tab_selection == "관리 도구":
    st.title("시스템 관리 도구")
    st.caption("데이터 재생성 및 시스템 관리")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("벡터 데이터베이스")
        st.markdown("**Pinecone 벡터 인덱스 재생성**")
        st.markdown("- DOCX 문서 → 벡터 임베딩 → Pinecone 업로드")
        st.markdown("- 시간: 약 30분 ~ 2시간")
        
        if st.button("벡터 재생성 시작", type="primary"):
            thread = threading.Thread(target=run_reindexing)
            thread.daemon = True
            thread.start()
            add_log("progress", "벡터 재생성 스레드 시작")
            st.success("벡터 재생성이 시작되었습니다. 진행 상황은 아래 로그를 확인하세요.")
    
    with col2:
        st.subheader("BM25 검색 인덱스")
        st.markdown("**BM25 검색 인덱스 재생성**")
        st.markdown("- DOCX 문서 → 텍스트 추출 → BM25 인덱스")
        st.markdown("- 시간: 약 10분 ~ 30분")
        
        if st.button("BM25 재생성 시작", type="secondary"):
            thread = threading.Thread(target=rebuild_bm25)
            thread.daemon = True
            thread.start()
            add_log("progress", "BM25 인덱스 재생성 스레드 시작")
            st.success("BM25 재생성이 시작되었습니다.")
    
    # 관리 도구 로그
    st.markdown("---")
    st.subheader("관리 로그")
    
    # 통합 로그 표시
    all_logs = []
    all_logs.extend([(log, "진행") for log in st.session_state.progress_logs])
    all_logs.extend([(log, "성공") for log in st.session_state.success_logs])
    all_logs.extend([(log, "실패") for log in st.session_state.failure_logs])
    
    # 시간순 정렬 (로그 앞쪽의 timestamp 기준)
    all_logs.sort(key=lambda x: x[0][:9])  # [HH:MM:SS] 부분으로 정렬
    
    if all_logs:
        # 최근 50개만 표시
        recent_logs = all_logs[-50:]
        log_display = []
        for log_msg, log_type in recent_logs:
            prefix = {"성공": "✓", "실패": "✗", "진행": "-"}[log_type]
            log_display.append(f"{prefix} {log_msg}")
        
        log_text = "\n".join(log_display)
        st.text_area("", value=log_text, height=400, key="management_logs")
    else:
        st.text_area("", value="관리 로그가 없습니다.", height=400, key="management_empty")
    
    # 로그 초기화 버튼
    if st.button("로그 초기화"):
        st.session_state.progress_logs = []
        st.session_state.success_logs = []
        st.session_state.failure_logs = []
        st.success("로그가 초기화되었습니다.")
        st.rerun()

# 푸터
st.markdown("---")
st.markdown(
    f"<div style='text-align: center; color: #666; font-size: 0.8em;'>"
    f"금융법령 통합 RAG 시스템 v2.0 | 현재 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    f"</div>",
    unsafe_allow_html=True
)