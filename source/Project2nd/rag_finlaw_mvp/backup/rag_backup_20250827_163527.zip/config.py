# config.py - 정리된 설정
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Config:
    """정리된 전역 설정"""
    
    # 프로젝트 루트
    project_root: Path = Path(__file__).parent
    
    # 검색 설정
    mcq_top_k: int = 10
    short_top_k: int = 15
    vector_candidate_k: int = 50
    
    # BM25/Vector 경로 - 환경변수 우선 사용
    bm25_index_path: str = field(default_factory=lambda: (
        os.getenv("BM25_PICKLE") 
        or str(Path(__file__).parent / "bm25_pkg" / "bm25_index.pkl")
    ))
    
    # LLM API Keys
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    upstage_api_key: str = os.getenv("UPSTAGE_API_KEY", "")
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    
    # Vector DB
    pinecone_api_key: str = os.getenv("PINECONE_API_KEY", "")
    pinecone_environment: str = os.getenv("PINECONE_ENVIRONMENT", "")
    pinecone_index_name: str = os.getenv("PINECONE_INDEX_NAME", "")
    
    # LLM 설정
    max_tokens: int = 1024
    llm_timeout: int = 60
    
    def validate(self):
        """필수 설정 검증"""
        errors = []
        if not (self.openai_api_key or self.upstage_api_key):
            errors.append("최소 하나의 LLM API 키가 필요합니다.")
        if not os.path.exists(self.bm25_index_path) and not self.pinecone_api_key:
            errors.append("BM25 인덱스 또는 Pinecone 중 하나는 필요합니다.")
        return errors

# 전역 설정 인스턴스
_config = None

def get_config():
    global _config
    if _config is None:
        _config = Config()
        errors = _config.validate()
        if errors:
            for error in errors:
                print(f"Config 오류: {error}")
            raise RuntimeError("Config 검증 실패")
    return _config