import json
import pandas as pd
from typing import List, Dict, Tuple
import re

def load_excel_mcq(path: str) -> List[Dict]:
    df = pd.read_excel(path, sheet_name="사지선다형")
    rows = []
    for _, r in df.iterrows():
        q = str(r.get("문제내용","")).strip()
        choices = [str(r.get(f"보기{i}", "")).strip() for i in range(1,5) if pd.notna(r.get(f"보기{i}")) and str(r.get(f"보기{i}")).strip()]
        answer = str(r.get("정답","")).strip()
        rows.append({"type":"mcq","question":q,"choices":choices,"answer":answer,"meta":{"law":str(r.get("법령명","")).strip(),"difficulty":str(r.get("난이도","")).strip()}})
    return rows

def load_excel_short(path: str) -> List[Dict]:
    df = pd.read_excel(path, sheet_name="단답형")
    rows = []
    for _, r in df.iterrows():
        q = str(r.get("문제내용","")).strip()
        answer = str(r.get("정답","")).strip()
        rows.append({"type":"short","question":q,"answer":answer,"meta":{"law":str(r.get("법령명","")).strip(),"difficulty":str(r.get("난이도","")).strip()}})
    return rows

def load_aihub_json(path: str) -> List[Dict]:
    with open(path, "r", encoding="utf-8-sig") as f:
        js = json.load(f)
    rows = []
    for doc in js.get("data", []):
        for para in doc.get("paragraphs", []):
            ctx_id = para.get("context_id")
            for qa in para.get("qas", []):
                qt = qa.get("qa_type")
                try: qt = int(qt)
                except: qt = -1
                q = qa.get("question","")
                ans = qa.get("answer",{})
                if qt in (0,1,2):  # 스팬/단답형 모두 short로
                    rows.append({"type":"short","question":q,"answer":ans.get("text",""),
                                 "meta":{"doc_id":doc.get("doc_id"),"context_id":ctx_id}})
                elif qt == 4:      # 사지선다
                    rows.append({"type":"mcq","question":q,"choices":ans.get("options",[]),
                                 "answer":ans.get("text",""),
                                 "meta":{"doc_id":doc.get("doc_id"),"context_id":ctx_id}})
    return rows

def _norm_date(s:str)->str:
    s = s.replace(" ", "")
    # '2000.4.1.' ↔ '2000-04-01' 대충 맞추는 예시(필요 시 더 정교화)
    s = re.sub(r'(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})\.?', r'\1.\2.\3.', s)
    return s

def em_f1(pred: str, gold: str):
    def norm(s):
        s = " ".join(str(s).strip().lower().split())
        s = _norm_date(s)
        return s
    p = norm(pred); g = norm(gold)
    em = 1 if p == g else 0
    ps = set(p.split()); gs = set(g.split())
    if len(ps)==0 or len(gs)==0: 
        f1 = 0.0
    else:
        prec = len(ps & gs) / len(ps)
        rec = len(ps & gs) / len(gs)
        f1 = 0.0 if (prec+rec)==0 else 2*prec*rec/(prec+rec)
    return em, f1

def mcq_acc(pred: str, gold: str) -> int:
    def norm(s): 
        return " ".join(str(s).strip().lower().split())
    return 1 if norm(pred) == norm(gold) else 0
