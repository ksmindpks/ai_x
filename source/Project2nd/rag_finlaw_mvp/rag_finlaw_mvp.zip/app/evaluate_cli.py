import argparse, json
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.utils import load_aihub_json, em_f1, mcq_acc
from rag.retriever import retrieve
from rag.generator import answer_short_extract, answer_mcq

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--val_json", required=True)
    ap.add_argument("--limit", type=int, default=50)
    return ap.parse_args()

def main():
    args = parse_args()
    rows = load_aihub_json(args.val_json)[:args.limit]
    s_em = s_f1 = s_acc = n_short = n_mcq = 0
    for r in rows:
        print(f"Q: {r['question']}")
        hits = retrieve(r["question"], filters=None, top_k=5)
        if r["type"] == "short":
            out = answer_short_extract(r["question"], hits)
            pred = ""
            for line in out.splitlines():
                if line.strip().startswith("정답:"):
                    pred = line.split("정답:", 1)[1].strip()
                    break
            em, f1 = em_f1(pred, r["answer"])
            s_em += em; s_f1 += f1; n_short += 1
        else:
            out = answer_mcq(r["question"], r.get("choices",[]), hits)
            pred = ""
            for line in out.splitlines():
                if line.strip().startswith("정답:"):
                    pred = line.split("정답:",1)[1].strip()
                    break
            s_acc += mcq_acc(pred, r["answer"]); n_mcq += 1
        print(f"A: {pred}, ref: {r['answer']}")
    if n_short:
        print(f"SHORT  EM={s_em/n_short:.3f}  F1={s_f1/n_short:.3f}  N={n_short}")
    if n_mcq:
        print(f"MCQ    ACC={s_acc/n_mcq:.3f}  N={n_mcq}")

if __name__ == "__main__":
    main()
