from dotenv import load_dotenv
import os

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY", "")
PINECONE_HOST = os.getenv("PINECONE_HOST", "")
PINECONE_INDEX = os.getenv("PINECONE_INDEX", "codedoc-law-index")
PINECONE_NAMESPACE = os.getenv("PINECONE_NAMESPACE", "default")
PINECONE_ENV = os.getenv("PINECONE_ENV", "us-east-1")

EMBED_MODEL = "text-embedding-3-large"
EMBED_DIM = 3072

TOP_K = int(os.getenv("TOP_K", "8"))
